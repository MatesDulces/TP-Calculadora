package Grafico;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Color;

public class Ecuaciones extends JFrame {
	
	ecuacion2x2 ventana_ecuaciones_2x2 = new ecuacion2x2();
	ecuacion3x3 ventana_ecuaciones_3x3 = new ecuacion3x3();
	Menu ventana_Menu = new Menu();
	Vectores ventana_Vectores = new Vectores();
	Matrices ventana_Matrices = new Matrices();
	
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ecuaciones frame = new Ecuaciones();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ecuaciones() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		JButton btn2x2 = new JButton("2 x 2");
		btn2x2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn2x2.setBackground(Color.LIGHT_GRAY);
		btn2x2.setForeground(Color.MAGENTA);
		btn2x2.setBounds(77, 86, 108, 60);
		btn2x2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ventana_ecuaciones_2x2.setVisible(true);
			}
		});
		contentPane.setLayout(null);
		contentPane.add(btn2x2);
		
		JButton btn3x3 = new JButton("3 x 3");
		btn3x3.setForeground(Color.MAGENTA);
		btn3x3.setBackground(Color.LIGHT_GRAY);
		btn3x3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn3x3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ventana_ecuaciones_3x3.setVisible(true);
			}
		});
		btn3x3.setBounds(245, 86, 108, 60);
		contentPane.add(btn3x3);
		
		JLabel lblNewLabel = new JLabel("Ecuaciones");
		lblNewLabel.setForeground(Color.MAGENTA);
		lblNewLabel.setBackground(Color.DARK_GRAY);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(114, 24, 194, 25);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 25));
		contentPane.add(lblNewLabel);
		
		JButton btnMenu = new JButton("HOME");
		btnMenu.setBackground(Color.LIGHT_GRAY);
		btnMenu.setForeground(Color.RED);
		btnMenu.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnMenu.setBounds(25, 202, 108, 37);
		contentPane.add(btnMenu);
		
		JButton btnVectores = new JButton("Vectores");
		btnVectores.setBackground(Color.LIGHT_GRAY);
		btnVectores.setForeground(Color.GREEN);
		btnVectores.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnVectores.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ventana_Vectores.setVisible(true);	
				dispose();
			}
		});
		btnVectores.setBounds(168, 202, 108, 37);
		contentPane.add(btnVectores);
		
		JButton btnMatrices = new JButton("Matrices");
		btnMatrices.setBackground(Color.LIGHT_GRAY);
		btnMatrices.setForeground(Color.RED);
		btnMatrices.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnMatrices.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ventana_Matrices.setVisible(true);	
				dispose();
			}
		});
		btnMatrices.setBounds(302, 205, 108, 31);
		contentPane.add(btnMatrices);
	}
}