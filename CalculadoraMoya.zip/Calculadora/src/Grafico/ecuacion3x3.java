package Grafico;

import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.UIManager;
import java.awt.SystemColor;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.Color;

public class ecuacion3x3 extends JFrame {
	
	Menu ventana_Menu = new Menu();

    private JPanel contentPane;
    private JTextField textFieldx1;
    private JTextField textFieldx2;
    private JTextField textFieldy1;
    private JTextField textFieldy2;
    private JTextField textFieldz1;
    private JTextField textField_z2;
    private JTextField textFieldx3;
    private JTextField textFieldy3;
    private JTextField textFieldz3;
    private JTextField textFieldr1;
    private JTextField textFieldr2;
    private JTextField textFieldr3;
    private JTextField focusedTextField; 
    private JTextField result1;
    private JTextField result2;
    private JTextField result3;
    private boolean isDecimalMode = false; // Variable para controlar el modo de nÃºmero (entero o decimal)
    
    
  
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ecuacion3x3 frame = new ecuacion3x3();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void insertarNumero(JButton boton) {
        boton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (focusedTextField != null) {
                    String numero = focusedTextField.getText() + boton.getText();
                    focusedTextField.setText(numero);
                }
            }
        });
    }
    
    private double determinant(double[][] matrix) {
        return matrix[0][0] * (matrix[1][1] * matrix[2][2] - matrix[1][2] * matrix[2][1])
             - matrix[0][1] * (matrix[1][0] * matrix[2][2] - matrix[1][2] * matrix[2][0])
             + matrix[0][2] * (matrix[1][0] * matrix[2][1] - matrix[1][1] * matrix[2][0]);
    }

    private double[] resolverSistemaEcuaciones(double[][] coeficientes, double[] resultados) throws Exception {
        double[][] matrizD = coeficientes;
        double detD = determinant(matrizD);
        
        if (detD == 0) {
            throw new Exception("El sistema no tiene soluciÃ³n Ãºnica.");
        }
        
        double[][] matrizDx = {
            { resultados[0], coeficientes[0][1], coeficientes[0][2] },
            { resultados[1], coeficientes[1][1], coeficientes[1][2] },
            { resultados[2], coeficientes[2][1], coeficientes[2][2] }
        };
        
        double[][] matrizDy = {
            { coeficientes[0][0], resultados[0], coeficientes[0][2] },
            { coeficientes[1][0], resultados[1], coeficientes[1][2] },
            { coeficientes[2][0], resultados[2], coeficientes[2][2] }
        };
        
        double[][] matrizDz = {
            { coeficientes[0][0], coeficientes[0][1], resultados[0] },
            { coeficientes[1][0], coeficientes[1][1], resultados[1] },
            { coeficientes[2][0], coeficientes[2][1], resultados[2] }
        };

        double detDx = determinant(matrizDx);
        double detDy = determinant(matrizDy);
        double detDz = determinant(matrizDz);

        double[] solution = new double[3];
        solution[0] = detDx / detD;
        solution[1] = detDy / detD;
        solution[2] = detDz / detD;

        return solution;
    }

    /**
     * Create the frame.
     */
    public ecuacion3x3() {
    	
    	
    	
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	setBounds(100, 100, 593, 647);
    	contentPane = new JPanel();
    	contentPane.setBackground(Color.DARK_GRAY);
    	contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

    	setContentPane(contentPane);
    	contentPane.setLayout(null);
    	
    	textField_z2 = new JTextField();
    	textField_z2.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	textField_z2.setEditable(false);
    	textField_z2.setColumns(10);
    	textField_z2.setBounds(357, 124, 61, 37);
    	contentPane.add(textField_z2);
    	
    	textFieldz1 = new JTextField();
    	textFieldz1.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	textFieldz1.setEditable(false);
    	textFieldz1.setColumns(10);
    	textFieldz1.setBounds(357, 56, 61, 37);
    	contentPane.add(textFieldz1);
    	
    	textFieldy2 = new JTextField();
    	textFieldy2.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	textFieldy2.setEditable(false);
    	textFieldy2.setColumns(10);
    	textFieldy2.setBounds(229, 124, 61, 37);
    	contentPane.add(textFieldy2);
    	
    	textFieldy1 = new JTextField();
    	textFieldy1.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	textFieldy1.setEditable(false);
    	textFieldy1.setColumns(10);
    	textFieldy1.setBounds(229, 56, 61, 37);
    	contentPane.add(textFieldy1);
    	
    	textFieldx2 = new JTextField();
    	textFieldx2.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	textFieldx2.setEditable(false);
    	textFieldx2.setColumns(10);
    	textFieldx2.setBounds(111, 124, 61, 37);
    	contentPane.add(textFieldx2);
    	
    	textFieldx1 = new JTextField();
    	textFieldx1.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	textFieldx1.setEditable(false);
    	textFieldx1.setBounds(111, 56, 61, 37);
    	contentPane.add(textFieldx1);
    	textFieldx1.setColumns(10);
    	
    	JLabel lblNewLabel = new JLabel("Ecuaciones 3x3");
    	lblNewLabel.setForeground(Color.MAGENTA);
    	lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
    	lblNewLabel.setBounds(182, 11, 209, 25);
    	lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 25));
    	contentPane.add(lblNewLabel);
    	
    	JTextPane txtpnEcuacion = new JTextPane();
    	txtpnEcuacion.setForeground(Color.MAGENTA);
    	txtpnEcuacion.setFont(new Font("Tahoma", Font.PLAIN, 15));
    	txtpnEcuacion.setEditable(false);
    	txtpnEcuacion.setBackground(Color.DARK_GRAY);
    	txtpnEcuacion.setText("Ecuacion 1");
    	txtpnEcuacion.setBounds(10, 36, 106, 20);
    	contentPane.add(txtpnEcuacion);
    	
    	JTextPane txtpnEcuacion_2 = new JTextPane();
    	txtpnEcuacion_2.setForeground(Color.MAGENTA);
    	txtpnEcuacion_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
    	txtpnEcuacion_2.setEditable(false);
    	txtpnEcuacion_2.setText("Ecuacion 2");
    	txtpnEcuacion_2.setBackground(Color.DARK_GRAY);
    	txtpnEcuacion_2.setBounds(10, 105, 106, 20);
    	contentPane.add(txtpnEcuacion_2);
    	
    	JTextPane txtpnX = new JTextPane();
    	txtpnX.setForeground(Color.WHITE);
    	txtpnX.setFont(new Font("Tahoma", Font.PLAIN, 15));
    	txtpnX.setEditable(false);
    	txtpnX.setText("x1=");
    	txtpnX.setBackground(Color.DARK_GRAY);
    	txtpnX.setBounds(40, 73, 61, 20);
    	contentPane.add(txtpnX);
    	
    	JTextPane txtpnX_1 = new JTextPane();
    	txtpnX_1.setForeground(Color.WHITE);
    	txtpnX_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
    	txtpnX_1.setEditable(false);
    	txtpnX_1.setText("x2=");
    	txtpnX_1.setBackground(Color.DARK_GRAY);
    	txtpnX_1.setBounds(40, 141, 61, 20);
    	contentPane.add(txtpnX_1);
    	
    	JTextPane txtpnY = new JTextPane();
    	txtpnY.setForeground(Color.WHITE);
    	txtpnY.setFont(new Font("Tahoma", Font.PLAIN, 15));
    	txtpnY.setEditable(false);
    	txtpnY.setText("y1=");
    	txtpnY.setBackground(Color.DARK_GRAY);
    	txtpnY.setBounds(199, 73, 61, 20);
    	contentPane.add(txtpnY);
    	
    	JTextPane txtpnY_1 = new JTextPane();
    	txtpnY_1.setForeground(Color.WHITE);
    	txtpnY_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
    	txtpnY_1.setEditable(false);
    	txtpnY_1.setText("y2=");
    	txtpnY_1.setBackground(Color.DARK_GRAY);
    	txtpnY_1.setBounds(199, 141, 61, 20);
    	contentPane.add(txtpnY_1);
    	
    	JTextPane txtpnZ = new JTextPane();
    	txtpnZ.setForeground(Color.WHITE);
    	txtpnZ.setFont(new Font("Tahoma", Font.PLAIN, 15));
    	txtpnZ.setEditable(false);
    	txtpnZ.setText("z1=");
    	txtpnZ.setBackground(Color.DARK_GRAY);
    	txtpnZ.setBounds(327, 73, 61, 20);
    	contentPane.add(txtpnZ);
    	
    	JTextPane txtpnZ_1 = new JTextPane();
    	txtpnZ_1.setForeground(Color.WHITE);
    	txtpnZ_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
    	txtpnZ_1.setEditable(false);
    	txtpnZ_1.setText("z2=");
    	txtpnZ_1.setBackground(Color.DARK_GRAY);
    	txtpnZ_1.setBounds(327, 141, 61, 20);
    	contentPane.add(txtpnZ_1);
    	
    	JTextPane txtpnEcuacion_2_1 = new JTextPane();
    	txtpnEcuacion_2_1.setForeground(Color.MAGENTA);
    	txtpnEcuacion_2_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
    	txtpnEcuacion_2_1.setEditable(false);
    	txtpnEcuacion_2_1.setText("Ecuacion 3");
    	txtpnEcuacion_2_1.setBackground(Color.DARK_GRAY);
    	txtpnEcuacion_2_1.setBounds(10, 172, 106, 20);
    	contentPane.add(txtpnEcuacion_2_1);
    	
    	textFieldx3 = new JTextField();
    	textFieldx3.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	textFieldx3.setEditable(false);
    	textFieldx3.setColumns(10);
    	textFieldx3.setBounds(111, 193, 61, 37);
    	contentPane.add(textFieldx3);
    	
    	textFieldy3 = new JTextField();
    	textFieldy3.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	textFieldy3.setEditable(false);
    	textFieldy3.setColumns(10);
    	textFieldy3.setBounds(229, 193, 61, 37);
    	contentPane.add(textFieldy3);
    	
    	textFieldz3 = new JTextField();
    	textFieldz3.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	textFieldz3.setEditable(false);
    	textFieldz3.setColumns(10);
    	textFieldz3.setBounds(357, 193, 61, 37);
    	contentPane.add(textFieldz3);
    	
    	JTextPane txtpnX_1_1 = new JTextPane();
    	txtpnX_1_1.setForeground(Color.WHITE);
    	txtpnX_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
    	txtpnX_1_1.setEditable(false);
    	txtpnX_1_1.setText("x3=");
    	txtpnX_1_1.setBackground(Color.DARK_GRAY);
    	txtpnX_1_1.setBounds(40, 210, 61, 20);
    	contentPane.add(txtpnX_1_1);
    	
    	JTextPane txtpnX_1_2 = new JTextPane();
    	txtpnX_1_2.setForeground(Color.WHITE);
    	txtpnX_1_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
    	txtpnX_1_2.setEditable(false);
    	txtpnX_1_2.setText("y3=");
    	txtpnX_1_2.setBackground(Color.DARK_GRAY);
    	txtpnX_1_2.setBounds(199, 210, 61, 20);
    	contentPane.add(txtpnX_1_2);
    	
    	JTextPane txtpnX_1_3 = new JTextPane();
    	txtpnX_1_3.setForeground(Color.WHITE);
    	txtpnX_1_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
    	txtpnX_1_3.setEditable(false);
    	txtpnX_1_3.setText("z3=");
    	txtpnX_1_3.setBackground(Color.DARK_GRAY);
    	txtpnX_1_3.setBounds(327, 210, 61, 20);
    	contentPane.add(txtpnX_1_3);
    	
    	textFieldr1 = new JTextField();
    	textFieldr1.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	textFieldr1.setEditable(false);
    	textFieldr1.setColumns(10);
    	textFieldr1.setBounds(450, 56, 61, 37);
    	contentPane.add(textFieldr1);
    	
    	textFieldr2 = new JTextField();
    	textFieldr2.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	textFieldr2.setEditable(false);
    	textFieldr2.setColumns(10);
    	textFieldr2.setBounds(450, 124, 61, 37);
    	contentPane.add(textFieldr2);
    	
    	textFieldr3 = new JTextField();
    	textFieldr3.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	textFieldr3.setEditable(false);
    	textFieldr3.setColumns(10);
    	textFieldr3.setBounds(450, 193, 61, 37);
    	contentPane.add(textFieldr3);
    	
    	JTextPane txtpnY_2 = new JTextPane();
    	txtpnY_2.setForeground(Color.WHITE);
    	txtpnY_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
    	txtpnY_2.setEditable(false);
    	txtpnY_2.setText("=");
    	txtpnY_2.setBackground(Color.DARK_GRAY);
    	txtpnY_2.setBounds(422, 73, 61, 20);
    	contentPane.add(txtpnY_2);
    	
    	JTextPane txtpnY_2_1 = new JTextPane();
    	txtpnY_2_1.setForeground(Color.WHITE);
    	txtpnY_2_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
    	txtpnY_2_1.setEditable(false);
    	txtpnY_2_1.setText("=");
    	txtpnY_2_1.setBackground(Color.DARK_GRAY);
    	txtpnY_2_1.setBounds(422, 141, 61, 20);
    	contentPane.add(txtpnY_2_1);
    	
    	JTextPane txtpnY_2_2 = new JTextPane();
    	txtpnY_2_2.setForeground(Color.LIGHT_GRAY);
    	txtpnY_2_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
    	txtpnY_2_2.setEditable(false);
    	txtpnY_2_2.setText("=");
    	txtpnY_2_2.setBackground(Color.DARK_GRAY);
    	txtpnY_2_2.setBounds(428, 210, 61, 20);
    	contentPane.add(txtpnY_2_2);
    	
    	JTextPane txtpnX_2 = new JTextPane();
    	txtpnX_2.setForeground(Color.WHITE);
    	txtpnX_2.setEditable(false);
    	txtpnX_2.setText("+");
    	txtpnX_2.setBackground(Color.DARK_GRAY);
    	txtpnX_2.setBounds(182, 73, 15, 20);
    	contentPane.add(txtpnX_2);
    	
    	JTextPane txtpnX_2_1 = new JTextPane();
    	txtpnX_2_1.setForeground(Color.WHITE);
    	txtpnX_2_1.setEditable(false);
    	txtpnX_2_1.setText("+");
    	txtpnX_2_1.setBackground(Color.DARK_GRAY);
    	txtpnX_2_1.setBounds(182, 141, 15, 20);
    	contentPane.add(txtpnX_2_1);
    	
    	JTextPane txtpnX_2_2 = new JTextPane();
    	txtpnX_2_2.setForeground(Color.WHITE);
    	txtpnX_2_2.setEditable(false);
    	txtpnX_2_2.setText("+");
    	txtpnX_2_2.setBackground(Color.DARK_GRAY);
    	txtpnX_2_2.setBounds(182, 210, 15, 20);
    	contentPane.add(txtpnX_2_2);
    	
    	JTextPane txtpnX_2_3 = new JTextPane();
    	txtpnX_2_3.setForeground(Color.WHITE);
    	txtpnX_2_3.setEditable(false);
    	txtpnX_2_3.setText("+");
    	txtpnX_2_3.setBackground(Color.DARK_GRAY);
    	txtpnX_2_3.setBounds(302, 73, 15, 20);
    	contentPane.add(txtpnX_2_3);
    	
    	JTextPane txtpnX_2_4 = new JTextPane();
    	txtpnX_2_4.setForeground(Color.WHITE);
    	txtpnX_2_4.setEditable(false);
    	txtpnX_2_4.setText("+");
    	txtpnX_2_4.setBackground(Color.DARK_GRAY);
    	txtpnX_2_4.setBounds(300, 141, 15, 20);
    	contentPane.add(txtpnX_2_4);
    	
    	JTextPane txtpnX_2_5 = new JTextPane();
    	txtpnX_2_5.setForeground(Color.WHITE);
    	txtpnX_2_5.setEditable(false);
    	txtpnX_2_5.setText("+");
    	txtpnX_2_5.setBackground(Color.DARK_GRAY);
    	txtpnX_2_5.setBounds(300, 210, 15, 20);
    	contentPane.add(txtpnX_2_5);

        JButton btn7 = new JButton("7");
        btn7.setForeground(Color.WHITE);
        btn7.setBackground(Color.LIGHT_GRAY);
    	btn7.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn7.setBounds(20, 270, 71, 69);
    	contentPane.add(btn7);
    	insertarNumero(btn7);
    	
    	JButton btn8 = new JButton("8");
    	btn8.setForeground(Color.WHITE);
    	btn8.setBackground(Color.LIGHT_GRAY);
    	btn8.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn8.setBounds(150, 270, 71, 69);
    	contentPane.add(btn8);
    	insertarNumero(btn8);
    	
    	JButton btn9 = new JButton("9");
    	btn9.setForeground(Color.WHITE);
    	btn9.setBackground(Color.LIGHT_GRAY);
    	btn9.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn9.setBounds(280, 270, 71, 69);
    	contentPane.add(btn9);
    	insertarNumero(btn9);
    	
    	JButton btn4 = new JButton("4");
    	btn4.setForeground(Color.WHITE);
    	btn4.setBackground(Color.LIGHT_GRAY);
    	btn4.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn4.setBounds(20, 363, 71, 69);
    	contentPane.add(btn4);
    	insertarNumero(btn4);
    	
    	JButton btn1 = new JButton("1");
    	btn1.setForeground(Color.WHITE);
    	btn1.setBackground(Color.LIGHT_GRAY);
    	btn1.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn1.setBounds(20, 448, 71, 69);
    	contentPane.add(btn1);
    	insertarNumero(btn1);
    	
    	JButton btnigual = new JButton("=");
    	btnigual.setForeground(new Color(0, 0, 0));
    	btnigual.setBackground(Color.LIGHT_GRAY);
    	btnigual.addActionListener(new ActionListener() {
    	    public void actionPerformed(ActionEvent e) {
    	        try {
    	            double[][] coeficientes = {
    	                    { Double.parseDouble(textFieldx1.getText()), Double.parseDouble(textFieldy1.getText()), Double.parseDouble(textFieldz1.getText()) },
    	                    { Double.parseDouble(textFieldx2.getText()), Double.parseDouble(textFieldy2.getText()), Double.parseDouble(textField_z2.getText()) },
    	                    { Double.parseDouble(textFieldx3.getText()), Double.parseDouble(textFieldy3.getText()), Double.parseDouble(textFieldz3.getText()) }
    	            };
    	            double[] resultados = {
    	                    Double.parseDouble(textFieldr1.getText()),
    	                    Double.parseDouble(textFieldr2.getText()),
    	                    Double.parseDouble(textFieldr3.getText())
    	            };

    	            double[] solucion = resolverSistemaEcuaciones(coeficientes, resultados);

    	            // Actualizar los campos de texto de los resultados
    	            result1.setText(String.format("%.2f", solucion[0]));
    	            result2.setText(String.format("%.2f", solucion[1]));
    	            result3.setText(String.format("%.2f", solucion[2]));

    	        } catch (Exception ex) {
    	            // Manejar la excepciÃ³n (por ejemplo, mostrar un mensaje de error)
    	            ex.printStackTrace();
    	        }
    	    }
    	});
    	btnigual.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btnigual.setBounds(387, 448, 71, 69);
    	contentPane.add(btnigual);
    	
    	JButton btn5 = new JButton("5");
    	btn5.setForeground(Color.WHITE);
    	btn5.setBackground(Color.LIGHT_GRAY);
    	btn5.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn5.setBounds(150, 363, 71, 69);
    	contentPane.add(btn5);
    	insertarNumero(btn5);
    	
    	JButton btn6 = new JButton("6");
    	btn6.setForeground(Color.WHITE);
    	btn6.setBackground(Color.LIGHT_GRAY);
    	btn6.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn6.setBounds(280, 363, 71, 69);
    	contentPane.add(btn6);
    	insertarNumero(btn6);
    	
    	JButton btn2 = new JButton("2");
    	btn2.setForeground(Color.WHITE);
    	btn2.setBackground(Color.LIGHT_GRAY);
    	btn2.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn2.setBounds(150, 448, 71, 69);
    	contentPane.add(btn2);
    	insertarNumero(btn2);
    	
    	JButton btn3 = new JButton("3");
    	btn3.setForeground(Color.WHITE);
    	btn3.setBackground(Color.LIGHT_GRAY);
    	btn3.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn3.setBounds(280, 448, 71, 69);
    	contentPane.add(btn3);
    	insertarNumero(btn3);
    	
    	JButton btn0 = new JButton("0");
    	btn0.setForeground(Color.WHITE);
    	btn0.setBackground(Color.LIGHT_GRAY);
    	btn0.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn0.setBounds(150, 528, 71, 69);
    	contentPane.add(btn0);
    	insertarNumero(btn0);

        JButton btnBorrar = new JButton("DEL");
        btnBorrar.setBackground(Color.LIGHT_GRAY);
        btnBorrar.setForeground(Color.RED);
        btnBorrar.setFont(new Font("Tahoma", Font.PLAIN, 15));
        btnBorrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (focusedTextField != null) {
                    String currentText = focusedTextField.getText();
                    if (currentText.length() > 0) {
                        focusedTextField.setText(currentText.substring(0, currentText.length() - 1));
                    }
                }
            }
        });
        btnBorrar.setBounds(387, 528, 71, 69);
        contentPane.add(btnBorrar);
        
        result1 = new JTextField();
        result1.setFont(new Font("Tahoma", Font.PLAIN, 20));
        result1.setEditable(false);
        result1.setColumns(10);
        result1.setBounds(422, 253, 61, 37);
        contentPane.add(result1);
        
        result2 = new JTextField();
        result2.setFont(new Font("Tahoma", Font.PLAIN, 20));
        result2.setEditable(false);
        result2.setColumns(10);
        result2.setBounds(422, 319, 61, 37);
        contentPane.add(result2);
        
        result3 = new JTextField();
        result3.setFont(new Font("Tahoma", Font.PLAIN, 20));
        result3.setEditable(false);
        result3.setColumns(10);
        result3.setBounds(422, 383, 61, 37);
        contentPane.add(result3);
        
        JTextPane Xrest = new JTextPane();
        Xrest.setFont(new Font("Tahoma", Font.PLAIN, 15));
        Xrest.setForeground(Color.MAGENTA);
        Xrest.setText("X=");
        Xrest.setEditable(false);
        Xrest.setBackground(Color.DARK_GRAY);
        Xrest.setBounds(377, 270, 61, 20);
        contentPane.add(Xrest);
        
        JTextPane Yrest = new JTextPane();
        Yrest.setFont(new Font("Tahoma", Font.PLAIN, 15));
        Yrest.setForeground(Color.MAGENTA);
        Yrest.setText("Y=");
        Yrest.setEditable(false);
        Yrest.setBackground(Color.DARK_GRAY);
        Yrest.setBounds(377, 336, 61, 20);
        contentPane.add(Yrest);
        
        JTextPane Zrest = new JTextPane();
        Zrest.setFont(new Font("Tahoma", Font.PLAIN, 15));
        Zrest.setForeground(Color.MAGENTA);
        Zrest.setText("Z=");
        Zrest.setEditable(false);
        Zrest.setBackground(Color.DARK_GRAY);
        Zrest.setBounds(377, 400, 61, 20);
        contentPane.add(Zrest);
        
        JButton btnNewButton = new JButton("HOME");
        btnNewButton.setForeground(Color.MAGENTA);
        btnNewButton.setBackground(Color.LIGHT_GRAY);
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
    				setVisible(false);
        	}
        });
        btnNewButton.setBounds(450, 11, 115, 37);
        contentPane.add(btnNewButton);
        

        JTextPane resultadoMensaje = new JTextPane();
        resultadoMensaje.setFont(new Font("Tahoma", Font.PLAIN, 15));
        resultadoMensaje.setForeground(Color.WHITE);
        resultadoMensaje.setEnabled(false);
        resultadoMensaje.setEditable(false);
        resultadoMensaje.setBackground(Color.DARK_GRAY);
        resultadoMensaje.setBounds(468, 429, 97, 88);
        contentPane.add(resultadoMensaje);

        btnigual.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    double[][] coeficientes = {
                        { Double.parseDouble(textFieldx1.getText()), Double.parseDouble(textFieldy1.getText()), Double.parseDouble(textFieldz1.getText()) },
                        { Double.parseDouble(textFieldx2.getText()), Double.parseDouble(textFieldy2.getText()), Double.parseDouble(textField_z2.getText()) },
                        { Double.parseDouble(textFieldx3.getText()), Double.parseDouble(textFieldy3.getText()), Double.parseDouble(textFieldz3.getText()) }
                    };

                    double[] resultados = {
                        Double.parseDouble(textFieldr1.getText()),
                        Double.parseDouble(textFieldr2.getText()),
                        Double.parseDouble(textFieldr3.getText())
                    };

                    double detD = determinant(coeficientes);

                    if (detD == 0) {
                        // Determinante de D es 0, ver si es compatible indeterminado o incompatible
                        double[][] augmentedMatrix1 = {
                            { coeficientes[0][0], coeficientes[0][1], coeficientes[0][2], resultados[0] },
                            { coeficientes[1][0], coeficientes[1][1], coeficientes[1][2], resultados[1] },
                            { coeficientes[2][0], coeficientes[2][1], coeficientes[2][2], resultados[2] }
                        };

                        // Calcular determinantes de matrices aumentadas para SCI o Incompatible
                        double detDx = determinant(new double[][] {
                            { augmentedMatrix1[0][1], augmentedMatrix1[0][2], augmentedMatrix1[0][3] },
                            { augmentedMatrix1[1][1], augmentedMatrix1[1][2], augmentedMatrix1[1][3] },
                            { augmentedMatrix1[2][1], augmentedMatrix1[2][2], augmentedMatrix1[2][3] }
                        });

                        double detDy = determinant(new double[][] {
                            { augmentedMatrix1[0][0], augmentedMatrix1[0][2], augmentedMatrix1[0][3] },
                            { augmentedMatrix1[1][0], augmentedMatrix1[1][2], augmentedMatrix1[1][3] },
                            { augmentedMatrix1[2][0], augmentedMatrix1[2][2], augmentedMatrix1[2][3] }
                        });

                        double detDz = determinant(new double[][] {
                            { augmentedMatrix1[0][0], augmentedMatrix1[0][1], augmentedMatrix1[0][3] },
                            { augmentedMatrix1[1][0], augmentedMatrix1[1][1], augmentedMatrix1[1][3] },
                            { augmentedMatrix1[2][0], augmentedMatrix1[2][1], augmentedMatrix1[2][3] }
                        });

                        if (detDx == 0 && detDy == 0 && detDz == 0) {
                            resultadoMensaje.setText("Sistema Compatible Indeterminado (SCI)");
                        } else {
                            resultadoMensaje.setText("Sistema Incompatible");
                        }
                        result1.setText("");
                        result2.setText("");
                        result3.setText("");
                    } else {
                        double[] solucion = resolverSistemaEcuaciones(coeficientes, resultados);
                        result1.setText(String.format("%.2f", solucion[0]));
                        result2.setText(String.format("%.2f", solucion[1]));
                        result3.setText(String.format("%.2f", solucion[2]));
                        resultadoMensaje.setText("Sistema Compatible Determinado (SCD)");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    resultadoMensaje.setText("Error en la entrada de datos");
                }
            }
        });

        
        JButton btnC = new JButton("C");
        btnC.setFont(new Font("Tahoma", Font.PLAIN, 15));
        btnC.setForeground(Color.RED);
        btnC.setBackground(Color.LIGHT_GRAY);
        btnC.addActionListener(new ActionListener() {
        	 public void actionPerformed(ActionEvent e) {
        	        textFieldx1.setText("");
        	        textFieldx2.setText("");
        	        textFieldx3.setText("");
        	        textFieldy1.setText("");
        	        textFieldy2.setText("");
        	        textFieldy3.setText("");
        	        textFieldz1.setText("");
        	        textField_z2.setText("");
        	        textFieldz3.setText("");
        	        textFieldr1.setText("");
        	        textFieldr2.setText("");
        	        textFieldr3.setText("");
        	        result1.setText("");
        	        result2.setText("");
        	        result3.setText("");
        	        resultadoMensaje.setText(null);
        	    }
        	});
        btnC.setBounds(496, 530, 71, 69);
        contentPane.add(btnC);
        
        JButton btnCambiarSigno = new JButton("+/-");
        btnCambiarSigno.setForeground(Color.WHITE);
        btnCambiarSigno.setBackground(Color.LIGHT_GRAY);
        btnCambiarSigno.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (focusedTextField != null) {
                    String currentText = focusedTextField.getText();
                    if (!currentText.isEmpty()) {
                        double number = Double.parseDouble(currentText);
                        number = -number; // Cambiar signo
                        focusedTextField.setText(Double.toString(number));
                    }
                }
            }
        });
        btnCambiarSigno.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnCambiarSigno.setBounds(20, 528, 71, 69);
        contentPane.add(btnCambiarSigno);

        JButton btnPunto = new JButton(",");
        btnPunto.setForeground(Color.WHITE);
        btnPunto.setBackground(Color.LIGHT_GRAY);
    	btnPunto.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (focusedTextField != null) {
                    String currentText = focusedTextField.getText();
                    if (!currentText.isEmpty()) {
                        if (isDecimalMode) {
                            // Convertir a entero
                            try {
                                int number = (int) Double.parseDouble(currentText);
                                focusedTextField.setText(Integer.toString(number));
                            } catch (NumberFormatException ex) {
                                // Handle parse error (shouldn't happen if input is controlled)
                                focusedTextField.setText("0");
                            }
                        } else {
                            // Convertir a decimal
                            try {
                                double number = Double.parseDouble(currentText);
                                focusedTextField.setText(Double.toString(number));
                            } catch (NumberFormatException ex) {
                                // Handle parse error (shouldn't happen if input is controlled)
                                focusedTextField.setText("0.0");
                            }
                        }
                        isDecimalMode = !isDecimalMode; // Alternar modo
                    }
                }
            }
        });
    btnPunto.setFont(new Font("Tahoma", Font.PLAIN, 20));
    btnPunto.setBounds(280, 528, 71, 69);
    contentPane.add(btnPunto);
    
    
        
        // Agregar FocusListener a cada campo de texto
        FocusAdapter focusAdapter = new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                focusedTextField = (JTextField) e.getSource();
            }
        };

        textFieldx1.addFocusListener(focusAdapter);
        textFieldx2.addFocusListener(focusAdapter);
        textFieldx3.addFocusListener(focusAdapter);
        textFieldy1.addFocusListener(focusAdapter);
        textFieldy2.addFocusListener(focusAdapter);
        textFieldy3.addFocusListener(focusAdapter);
        textFieldz1.addFocusListener(focusAdapter);
        textField_z2.addFocusListener(focusAdapter);
        textFieldz3.addFocusListener(focusAdapter);
        textFieldr1.addFocusListener(focusAdapter);
        textFieldr2.addFocusListener(focusAdapter);
        textFieldr3.addFocusListener(focusAdapter);
    }
}
