package Grafico;

import java.awt.Component;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class Matrices extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JButton btnNewButton_2;
	private JButton btnNewButton_3;
	private JButton btnNewButton_4;
	private JButton btnNewButton_5;
	private JButton btnNewButton_7;
	private JButton btnNewButton_8;
	private JTextField[][] MatrizA;
    private JTextField[][] MatrizB;
    private JTextField[][] MatrizResultado;
    private JButton btnNewButton_11;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Matrices frame = new Matrices();
					frame.setVisible(true);
					frame.crearMatrices3x3();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	private void crearMatrices2x2() {
	    limpiarMatrices();

	    MatrizA = new JTextField[2][2];
	    MatrizB = new JTextField[2][2];
	    MatrizResultado = new JTextField[2][2];

	    for (int i = 0; i < 2; i++) {
	        for (int j = 0; j < 2; j++) {
	            MatrizA[i][j] = new JTextField();
	            MatrizA[i][j].setBounds(60 + j * 90, 100 + i * 100, 80, 80);
	            contentPane.add(MatrizA[i][j]);

	            MatrizB[i][j] = new JTextField();
	            MatrizB[i][j].setBounds(500 + j * 90, 100 + i * 100, 80, 80);
	            contentPane.add(MatrizB[i][j]);

	            MatrizResultado[i][j] = new JTextField();
	            MatrizResultado[i][j].setBounds(850 + j * 90, 100 + i * 100, 80, 80);
	            MatrizResultado[i][j].setEditable(true);
	            contentPane.add(MatrizResultado[i][j]);
	        }
	    }
	    contentPane.revalidate();
	    contentPane.repaint();
	}

	private void crearMatrices3x3() {
	    limpiarMatrices();

	    MatrizA = new JTextField[3][3];
	    MatrizB = new JTextField[3][3];
	    MatrizResultado = new JTextField[3][3];

	    for (int i = 0; i < 3; i++) {
	        for (int j = 0; j < 3; j++) {
	            MatrizA[i][j] = new JTextField();
	            MatrizA[i][j].setBounds(20 + j * 90, 50 + i * 100, 70, 70);
	            contentPane.add(MatrizA[i][j]);

	            MatrizB[i][j] = new JTextField();
	            MatrizB[i][j].setBounds(450 + j * 90, 50 + i * 100, 70, 70);
	            contentPane.add(MatrizB[i][j]);

	            MatrizResultado[i][j] = new JTextField();
	            MatrizResultado[i][j].setBounds(770 + j * 90, 50 + i * 100, 70, 70);
	            MatrizResultado[i][j].setEditable(true);
	            contentPane.add(MatrizResultado[i][j]);
	        }
	    }
	    contentPane.revalidate();
	    contentPane.repaint();
	}

	private void limpiarMatrices() {
	    Component[] componentes = contentPane.getComponents();
	    for (Component componente : componentes) {
	        if (componente instanceof JTextField) {
	            contentPane.remove(componente);
	        }
	    }
	    MatrizA = null;
	    MatrizB = null;
	    MatrizResultado = null;
	}
	private void sumarMatrices() {
	    // Determinar el tamaño de las matrices
	    int filas = MatrizA.length;
	    int columnas = MatrizA[0].length;

	    // Realizar la suma
	    for (int i = 0; i < filas; i++) {
	        for (int j = 0; j < columnas; j++) {
	            try {
	                // Obtener valores de MatrizA y MatrizB
	                double valorA = Double.parseDouble(MatrizA[i][j].getText());
	                double valorB = Double.parseDouble(MatrizB[i][j].getText());

	                // Sumar los valores
	                double resultado = valorA + valorB;

	                // Escribir el resultado en MatrizResultado
	                MatrizResultado[i][j].setText(String.format("%.2f", resultado));
	            } catch (NumberFormatException e) {
	                JOptionPane.showMessageDialog(null, "Por favor, ingrese números válidos en todas las celdas.");
	                return;
	            }
	        }
	    }

	    contentPane.revalidate();
	    contentPane.repaint();
	}
	private void restarMatrices() {
	    // Determinar el tamaño de las matrices
	    int filas = MatrizA.length;
	    int columnas = MatrizA[0].length;

	    // Realizar la suma
	    for (int i = 0; i < filas; i++) {
	        for (int j = 0; j < columnas; j++) {
	            try {
	                // Obtener valores de MatrizA y MatrizB
	                double valorA = Double.parseDouble(MatrizA[i][j].getText());
	                double valorB = Double.parseDouble(MatrizB[i][j].getText());

	                // Sumar los valores
	                double resultado = valorA - valorB;

	                // Escribir el resultado en MatrizResultado
	                MatrizResultado[i][j].setText(String.format("%.2f", resultado));
	            } catch (NumberFormatException e) {
	                JOptionPane.showMessageDialog(null, "Por favor, ingrese números válidos en todas las celdas.");
	                return;
	            }
	        }
	    }

	    contentPane.revalidate();
	    contentPane.repaint();
	}
	private void multiplicarMatrices() {
	    int filasA = MatrizA.length;
	    int columnasA = MatrizA[0].length;
	    int filasB = MatrizB.length;
	    int columnasB = MatrizB[0].length;

	    // Verificar si las matrices se pueden multiplicar
	    if (columnasA != filasB) {
	        JOptionPane.showMessageDialog(null, "Error: No se pueden multiplicar estas matrices. El número de columnas de A debe ser igual al número de filas de B.");
	        return;
	    }

	    // Realizar la multiplicación
	    for (int i = 0; i < filasA; i++) {
	        for (int j = 0; j < columnasB; j++) {
	            double suma = 0;
	            for (int k = 0; k < columnasA; k++) {
	                try {
	                    double valorA = Double.parseDouble(MatrizA[i][k].getText());
	                    double valorB = Double.parseDouble(MatrizB[k][j].getText());
	                    suma += valorA * valorB;
	                } catch (NumberFormatException e) {
	                    JOptionPane.showMessageDialog(null, "Por favor, ingrese números válidos en todas las celdas.");
	                    return;
	                }
	            }
	            MatrizResultado[i][j].setText(String.format("%.2f", suma));
	        }
	    }

	    contentPane.revalidate();
	    contentPane.repaint();
	}
	private void dividirMatrices() {
	    int size = MatrizA.length;
	    if (size != MatrizA[0].length || size != MatrizB.length || size != MatrizB[0].length || (size != 2 && size != 3)) {
	        JOptionPane.showMessageDialog(null, "Esta operación solo está implementada para matrices cuadradas 2x2 o 3x3.");
	        return;
	    }

	    try {
	        double[][] matrizB = new double[size][size];
	        for (int i = 0; i < size; i++) {
	            for (int j = 0; j < size; j++) {
	                matrizB[i][j] = Double.parseDouble(MatrizB[i][j].getText());
	            }
	        }

	        double[][] inverseB = invertMatrix(matrizB);
	        if (inverseB == null) {
	            JOptionPane.showMessageDialog(null, "La matriz B no es invertible (determinante es cero).");
	            return;
	        }

	        for (int i = 0; i < size; i++) {
	            for (int j = 0; j < size; j++) {
	                double sum = 0;
	                for (int k = 0; k < size; k++) {
	                    double valorA = Double.parseDouble(MatrizA[i][k].getText());
	                    sum += valorA * inverseB[k][j];
	                }
	                MatrizResultado[i][j].setText(String.format("%.2f", sum));
	            }
	        }

	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(null, "Por favor, ingrese números válidos en todas las celdas.");
	    }

	    contentPane.revalidate();
	    contentPane.repaint();
	}

	private double[][] invertMatrix(double[][] matrix) {
	    int n = matrix.length;
	    double[][] augmented = new double[n][2*n];
	    
	    for (int i = 0; i < n; i++) {
	        System.arraycopy(matrix[i], 0, augmented[i], 0, n);
	        augmented[i][i + n] = 1;
	    }

	
	    for (int i = 0; i < n; i++) {
	        int max = i;
	        for (int j = i + 1; j < n; j++) {
	            if (Math.abs(augmented[j][i]) > Math.abs(augmented[max][i])) {
	                max = j;
	            }
	        }


	        double[] temp = augmented[i];
	        augmented[i] = augmented[max];
	        augmented[max] = temp;


	        for (int j = i + 1; j < n; j++) {
	            double c = -augmented[j][i] / augmented[i][i];
	            for (int k = i; k < 2*n; k++) {
	                if (i == k) {
	                    augmented[j][k] = 0;
	                } else {
	                    augmented[j][k] += c * augmented[i][k];
	                }
	            }
	        }
	    }


	    for (int i = n - 1; i >= 0; i--) {
	        for (int j = i - 1; j >= 0; j--) {
	            double c = -augmented[j][i] / augmented[i][i];
	            for (int k = 0; k < 2*n; k++) {
	                augmented[j][k] += c * augmented[i][k];
	            }
	        }
	    }


	    for (int i = 0; i < n; i++) {
	        double c = 1.0 / augmented[i][i];
	        for (int j = 0; j < 2*n; j++) {
	            augmented[i][j] *= c;
	        }
	    }

	    double[][] inverse = new double[n][n];
	    for (int i = 0; i < n; i++) {
	        System.arraycopy(augmented[i], n, inverse[i], 0, n);
	    }

	    return inverse;
	}

	private void calcularDeterminanteA() {
	    if (MatrizA == null) {
	        JOptionPane.showMessageDialog(null, "Por favor, cree la matriz A primero.");
	        return;
	    }

	    try {
	        double detA = calcularDeterminante(MatrizA);
	        JOptionPane.showMessageDialog(null, "Determinante de la Matriz A: " + String.format("%.2f", detA));
	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(null, "Por favor, ingrese números válidos en todas las celdas de la Matriz A.");
	    }
	}

	private void calcularDeterminanteB() {
	    if (MatrizB == null) {
	        JOptionPane.showMessageDialog(null, "Por favor, cree la matriz B primero.");
	        return;
	    }

	    try {
	        double detB = calcularDeterminante(MatrizB);
	        JOptionPane.showMessageDialog(null, "Determinante de la Matriz B: " + String.format("%.2f", detB));
	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(null, "Por favor, ingrese números válidos en todas las celdas de la Matriz B.");
	    }
	}

	private double calcularDeterminante(JTextField[][] matriz) {
	    int size = matriz.length;
	    if (size == 2) {
	        double a = Double.parseDouble(matriz[0][0].getText());
	        double b = Double.parseDouble(matriz[0][1].getText());
	        double c = Double.parseDouble(matriz[1][0].getText());
	        double d = Double.parseDouble(matriz[1][1].getText());
	        return a * d - b * c;
	    } else if (size == 3) {
	        double a = Double.parseDouble(matriz[0][0].getText());
	        double b = Double.parseDouble(matriz[0][1].getText());
	        double c = Double.parseDouble(matriz[0][2].getText());
	        double d = Double.parseDouble(matriz[1][0].getText());
	        double e = Double.parseDouble(matriz[1][1].getText());
	        double f = Double.parseDouble(matriz[1][2].getText());
	        double g = Double.parseDouble(matriz[2][0].getText());
	        double h = Double.parseDouble(matriz[2][1].getText());
	        double i = Double.parseDouble(matriz[2][2].getText());
	        
	        return a*(e*i - f*h) - b*(d*i - f*g) + c*(d*h - e*g);
	    } else {
	        throw new IllegalArgumentException("El cálculo de determinante solo está implementado para matrices 2x2 y 3x3");
	    }
	}
	private void invertirMatrizA() {
	    if (MatrizA == null) {
	        JOptionPane.showMessageDialog(null, "Por favor, cree la matriz A primero.");
	        return;
	    }

	    int size = MatrizA.length;
	    if (size != MatrizA[0].length || (size != 2 && size != 3)) {
	        JOptionPane.showMessageDialog(null, "Esta operación solo está implementada para matrices cuadradas 2x2 o 3x3.");
	        return;
	    }

	    try {
	        // Primero, calculamos el determinante
	        double detA = calcularDeterminante(MatrizA);
	        if (Math.abs(detA) < 1e-10) { // Comparamos con un valor muy pequeño para manejar errores de redondeo
	            JOptionPane.showMessageDialog(null, "La matriz A no es invertible (determinante es cero).");
	            return;
	        }

	        double[][] matrizA = new double[size][size];
	        for (int i = 0; i < size; i++) {
	            for (int j = 0; j < size; j++) {
	                matrizA[i][j] = Double.parseDouble(MatrizA[i][j].getText());
	            }
	        }

	        double[][] inverseA = invertMatrix(matrizA);
	        if (inverseA == null) {
	            JOptionPane.showMessageDialog(null, "Error al calcular la inversa de la matriz A.");
	            return;
	        }

	        for (int i = 0; i < size; i++) {
	            for (int j = 0; j < size; j++) {
	                MatrizResultado[i][j].setText(String.format("%.2f", inverseA[i][j]));
	            }
	        }

	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(null, "Por favor, ingrese números válidos en todas las celdas de la Matriz A.");
	    }
	}

private void invertirMatrizB() {
	    if (MatrizB == null) {
	        JOptionPane.showMessageDialog(null, "Por favor, cree la matriz B primero.");
	        return;
	    }

	    int size = MatrizB.length;
	    if (size != MatrizB[0].length || (size != 2 && size != 3)) {
	        JOptionPane.showMessageDialog(null, "Esta operación solo está implementada para matrices cuadradas 2x2 o 3x3.");
	        return;
	    }

	    try {
	        // Primero, calculamos el determinante
	        double detB = calcularDeterminante(MatrizB);
	        if (Math.abs(detB) < 1e-10) { // Comparamos con un valor muy pequeño para manejar errores de redondeo
	            JOptionPane.showMessageDialog(null, "La matriz B no es invertible (determinante es cero).");
	            return;
	        }

	        double[][] matrizB = new double[size][size];
	        for (int i = 0; i < size; i++) {
	            for (int j = 0; j < size; j++) {
	                matrizB[i][j] = Double.parseDouble(MatrizB[i][j].getText());
	            }
	        }

	        double[][] inverseB = invertMatrix(matrizB);
	        if (inverseB == null) {
	            JOptionPane.showMessageDialog(null, "Error al calcular la inversa de la matriz B.");
	            return;
	        }

	        for (int i = 0; i < size; i++) {
	            for (int j = 0; j < size; j++) {
	                MatrizResultado[i][j].setText(String.format("%.2f", inverseB[i][j]));
	            }
	        }

	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(null, "Por favor, ingrese números válidos en todas las celdas de la Matriz B.");
	    }
	}
	/**
	 * Create the frame.
	 */
	public Matrices() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1106, 468);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Matrices");
		lblNewLabel.setBounds(326, 11, 74, 25);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("+");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sumarMatrices();
			}
		});
		btnNewButton.setBounds(293, 79, 145, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("-");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				restarMatrices();
			}
		});
		btnNewButton_1.setBounds(293, 124, 145, 23);
		contentPane.add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("x");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				multiplicarMatrices();
			}
		});
		btnNewButton_2.setBounds(293, 170, 145, 23);
		contentPane.add(btnNewButton_2);
		
		btnNewButton_3 = new JButton("/");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dividirMatrices();
			}
		});
		btnNewButton_3.setBounds(293, 215, 145, 23);
		contentPane.add(btnNewButton_3);
		
		btnNewButton_4 = new JButton("Determinante A");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				calcularDeterminanteA();
			}
		});
		btnNewButton_4.setBounds(23, 323, 128, 23);
		contentPane.add(btnNewButton_4);
		
		btnNewButton_5 = new JButton("Inversa A");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				invertirMatrizA();
			}
		});
		btnNewButton_5.setBounds(155, 323, 128, 23);
		contentPane.add(btnNewButton_5);
		
		btnNewButton_7 = new JButton("Determinante B");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				calcularDeterminanteB();
			}
		});
		btnNewButton_7.setBounds(448, 323, 128, 23);
		contentPane.add(btnNewButton_7);
		
		btnNewButton_8 = new JButton("Inversa B");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				invertirMatrizB();
				
			}
		});
		btnNewButton_8.setBounds(580, 323, 128, 23);
		contentPane.add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("Menu");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnNewButton_9.setBounds(23, 16, 89, 23);
		contentPane.add(btnNewButton_9);
		
		JButton btnNewButton_10 = new JButton("2x2");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				crearMatrices2x2();
			}
		});
		btnNewButton_10.setBounds(326, 357, 89, 23);
		contentPane.add(btnNewButton_10);
		
		btnNewButton_11 = new JButton("3x3");
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				crearMatrices3x3();
			}
		});
		btnNewButton_11.setBounds(326, 391, 89, 23);
		contentPane.add(btnNewButton_11);
		
		JLabel lblNewLabel_1 = new JLabel("=");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(734, 179, 46, 14);
		contentPane.add(lblNewLabel_1);
	}
}
