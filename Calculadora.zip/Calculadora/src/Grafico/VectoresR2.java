package Grafico;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.*;
import javax.swing.JLabel;
import java.awt.Color;

public class VectoresR2 extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldx1;
	private JTextField textFieldy1;
	private JTextField textFieldx2;
	private JTextField textFieldy2;
///
	//vector 1
	float x1,y1;
	//vector 2
	float x2,y2;
	
	int count=0;
	int variX=0;
///
	String numero = null;
	private JTextField resultField;
	private JTextField multi_por;
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VectoresR2 frame = new VectoresR2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
		});
	}
	
	
	private void insertarn(JButton boton) 
	{
		boton.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent e)
			{
				if(variX==1) 
				{
					numero = multi_por.getText() + boton.getText();
                    multi_por.setText(numero);
                    
				}	else {
					switch(count) {
					
						case 0:
							numero=	textFieldx1.getText()+ boton.getText();
							textFieldx1.setText(numero);
							numero=null;
							count=1;
							break;
						case 1:
							numero=	textFieldy1.getText()+ boton.getText();
							textFieldy1.setText(numero);
							numero=null;
							count=2;
							break;
						case 2:
							numero=	textFieldx2.getText()+ boton.getText();
							textFieldx2.setText(numero);
							numero=null;
							count=3;
							break;
						case 3:
							numero=	textFieldy2.getText()+ boton.getText();
							textFieldy2.setText(numero);
							numero=null;
							count=4;
							break;
						case 4:
							count=0;
							break;
						}
				
					}
			
			}
			});
	}
	//llenar variables de x,y
	   private void parseVectorInputs() {
	        x1 = Float.parseFloat(textFieldx1.getText());
	        y1 = Float.parseFloat(textFieldy1.getText());
	        x2 = Float.parseFloat(textFieldx2.getText());
	        y2 = Float.parseFloat(textFieldy2.getText());
	    }
	   //llenar variables para producto escalar
	   private void productollenar() {
	        x1 = Float.parseFloat(textFieldx1.getText());
	        y1 = Float.parseFloat(textFieldy1.getText());
	    }
	   
	   //suma de vectores
	   private void sumvec() {
		   resultField.setText(null);
		   if(count==4) {
	        parseVectorInputs();
	        float sumX = x1 + x2;
	        float sumY = y1 + y2;
	        resultField.setText("(" + sumX + ", " + sumY + ")");
		   }	else 
		   		{
			   resultField.setText("Error, ingrese todos los valores");
		   		}
	    }
	
	   //resta vectores
	   private void restavec() {
		   resultField.setText(null);
		   if(count==4) {
	        parseVectorInputs();
	        float resX = x1 - x2;
	        float resY = y1 - y2;
	        resultField.setText("(" + resX + ", " + resY + ")");
		   }else 
		   {
			   resultField.setText("Error, ingrese todos los valores");
		   }
	    }
	   //multiplicacion por escalar
	   private void multiesc() {
		   productollenar();
	        float escalar = Float.parseFloat(multi_por.getText());
	        float resX = x1 * escalar;
	        float resY = y1 * escalar;
	        resultField.setText("(" + resX + ", " + resY + ")");
	    }
	   //producto escalar
	   private void prodESC() {
		   resultField.setText(null);
		   if(count==4) {
	        parseVectorInputs();
	        float dotProduct = x1 * x2 + y1 * y2;
	        resultField.setText(String.valueOf(dotProduct));
		   }else 
		   {
			   resultField.setText("Error, ingrese todos los valores");
		   }
	    }
	
	/**
	 * Create the frame.
	 */
	public VectoresR2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 538);
		contentPane =  new JPanel();
		contentPane.setForeground(Color.WHITE);
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btn7 = new JButton("7");
		btn7.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn7.setForeground(Color.WHITE);
		btn7.setBackground(Color.LIGHT_GRAY);
		btn7.setBounds(45, 243, 70, 58);
		contentPane.add(btn7);
		insertarn(btn7);
		
		JButton btn8 = new JButton("8");
		btn8.setBackground(Color.LIGHT_GRAY);
		btn8.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn8.setForeground(Color.WHITE);
		btn8.setBounds(147, 243, 70, 58);
		contentPane.add(btn8);
		insertarn(btn8);
		
		JButton btn9 = new JButton("9");
		btn9.setBackground(Color.LIGHT_GRAY);
		btn9.setForeground(Color.WHITE);
		btn9.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn9.setBounds(245, 243, 70, 58);
		contentPane.add(btn9);
		insertarn(btn9);
		
		
		
		JButton btn4 = new JButton("4");
		btn4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn4.setForeground(Color.WHITE);
		btn4.setBackground(Color.LIGHT_GRAY);
		btn4.setBounds(45, 305, 70, 58);
		contentPane.add(btn4);
		insertarn(btn4);
		
		JButton btn5 = new JButton("5");
		btn5.setBackground(Color.LIGHT_GRAY);
		btn5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn5.setForeground(Color.WHITE);
		btn5.setBounds(147, 305, 70, 58);
		contentPane.add(btn5);
		insertarn(btn5);
		
		JButton btn6 = new JButton("6");
		btn6.setForeground(Color.WHITE);
		btn6.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn6.setBackground(Color.LIGHT_GRAY);
		btn6.setBounds(245, 305, 70, 58);
		contentPane.add(btn6);
		insertarn(btn6);
		
		
		
		JButton btn1 = new JButton("1");
		btn1.setForeground(Color.WHITE);
		btn1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn1.setBackground(Color.LIGHT_GRAY);
		btn1.setBounds(45, 368, 70, 58);
		contentPane.add(btn1);
		insertarn(btn1);
		
		JButton btn2 = new JButton("2");
		btn2.setBackground(Color.LIGHT_GRAY);
		btn2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn2.setForeground(Color.WHITE);
		btn2.setBounds(147, 368, 70, 58);
		contentPane.add(btn2);
		insertarn(btn2);
		
		JButton btn3 = new JButton("3");
		btn3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn3.setForeground(Color.WHITE);
		btn3.setBackground(Color.LIGHT_GRAY);
		btn3.setBounds(245, 368, 70, 58);
		contentPane.add(btn3);
		insertarn(btn3);
		
		
		
		JButton btn0 = new JButton("0");
		btn0.setForeground(Color.WHITE);
		btn0.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn0.setBackground(Color.LIGHT_GRAY);
		btn0.setBounds(147, 430, 70, 58);
		contentPane.add(btn0);
		insertarn(btn0);
	
		
		
		
		
		JLabel lblNewLabel = new JLabel("Vector 1");
		lblNewLabel.setBackground(Color.DARK_GRAY);
		lblNewLabel.setForeground(Color.GREEN);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(10, 11, 95, 19);
		contentPane.add(lblNewLabel);
		
		JLabel lblVector = new JLabel("Vector 2");
		lblVector.setBackground(Color.DARK_GRAY);
		lblVector.setForeground(Color.GREEN);
		lblVector.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblVector.setBounds(10, 154, 95, 25);
		contentPane.add(lblVector);
		
		JLabel lblNewLabel_1 = new JLabel(",");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(204, 137, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel(",");
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1_1.setBounds(204, 58, 46, 14);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_2 = new JLabel("(");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setBackground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(35, 47, 46, 32);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("(");
		lblNewLabel_2_1.setForeground(Color.WHITE);
		lblNewLabel_2_1.setBackground(Color.DARK_GRAY);
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_1.setBounds(35, 106, 46, 32);
		contentPane.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel(")");
		lblNewLabel_2_1_1.setForeground(Color.WHITE);
		lblNewLabel_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_1_1.setBounds(367, 106, 46, 32);
		contentPane.add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel_2_1_2 = new JLabel(")");
		lblNewLabel_2_1_2.setForeground(Color.WHITE);
		lblNewLabel_2_1_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_1_2.setBounds(367, 47, 46, 32);
		contentPane.add(lblNewLabel_2_1_2);
		
		JButton btnmultiescalar = new JButton("=");
		btnmultiescalar.setForeground(Color.WHITE);
		btnmultiescalar.setBackground(Color.LIGHT_GRAY);
		btnmultiescalar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				multiesc();
			}
		});
		btnmultiescalar.setBounds(343, 127, 70, 39);
		contentPane.add(btnmultiescalar);
		btnmultiescalar.setVisible(false);
		
		
		JButton escalar = new JButton("X");
		escalar.setBackground(Color.GRAY);
		escalar.setFont(new Font("Tahoma", Font.PLAIN, 20));
		escalar.setForeground(Color.WHITE);
		escalar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textFieldx2.setVisible(false);
				textFieldy2.setVisible(false);
				lblVector.setVisible(false);
				lblNewLabel_2_1.setVisible(false);
				lblNewLabel_1.setVisible(false);
				lblNewLabel_2_1_1.setVisible(false);
				multi_por.setVisible(true);
				btnmultiescalar.setVisible(true);
				variX=1;
			}
		});
		escalar.setBounds(343, 430, 81, 58);
		contentPane.add(escalar);
		
		
		
		//boton XESC
		JButton XESC = new JButton("xesc");
		XESC.setFont(new Font("Tahoma", Font.PLAIN, 20));
		XESC.setBackground(Color.GRAY);
		XESC.setForeground(Color.WHITE);
		XESC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				variX=0;
				multi_por.setText(null);
				textFieldx2.setVisible(true);
				textFieldy2.setVisible(true);
				lblVector.setVisible(true);
				lblNewLabel_2_1.setVisible(true);
				lblNewLabel_1.setVisible(true);
				lblNewLabel_2_1_1.setVisible(true);
				multi_por.setVisible(false);
				btnmultiescalar.setVisible(false);
				prodESC();
			}
		});
		XESC.setBounds(343, 243, 81, 58);
		contentPane.add(XESC);
		
		
		//Boton mas
				JButton mas = new JButton("+");
				mas.setFont(new Font("Tahoma", Font.PLAIN, 20));
				mas.setForeground(Color.WHITE);
				mas.setBackground(Color.GRAY);
				mas.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						variX=0;
						multi_por.setText(null);
						textFieldx2.setVisible(true);
						textFieldy2.setVisible(true);
						lblVector.setVisible(true);
						lblNewLabel_2_1.setVisible(true);
						lblNewLabel_1.setVisible(true);
						lblNewLabel_2_1_1.setVisible(true);
						multi_por.setVisible(false);
						btnmultiescalar.setVisible(false);
						sumvec();
					}
				});
				mas.setBounds(343, 305, 81, 58);
				contentPane.add(mas);
				
				
				//boton menos
				JButton menos = new JButton("-");
				menos.setForeground(Color.WHITE);
				menos.setFont(new Font("Tahoma", Font.PLAIN, 20));
				menos.setBackground(Color.GRAY);
				menos.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						variX=0;
						multi_por.setText(null);
						textFieldx2.setVisible(true);
						textFieldy2.setVisible(true);
						lblVector.setVisible(true);
						lblNewLabel_2_1.setVisible(true);
						lblNewLabel_1.setVisible(true);
						lblNewLabel_2_1_1.setVisible(true);
						multi_por.setVisible(false);
						btnmultiescalar.setVisible(false);
						restavec();
					}
				});
				menos.setBounds(343, 368, 81, 58);
				contentPane.add(menos);
				
				
		
		textFieldx1 = new JTextField();
		textFieldx1.setEditable(false);
		textFieldx1.setFont(new Font("Arial", Font.PLAIN, 15));
		textFieldx1.setBounds(58, 42, 112, 48);
		contentPane.add(textFieldx1);
		textFieldx1.setColumns(10);
		
		
		
		textFieldy1 = new JTextField();
		textFieldy1.setEditable(false);
		textFieldy1.setFont(new Font("Arial", Font.PLAIN, 15));
		textFieldy1.setColumns(10);
		textFieldy1.setBounds(245, 42, 112, 48);
		contentPane.add(textFieldy1);
		
		textFieldx2 = new JTextField();
		textFieldx2.setEditable(false);
		textFieldx2.setFont(new Font("Arial", Font.PLAIN, 15));
		textFieldx2.setColumns(10);
		textFieldx2.setBounds(58, 101, 112, 48);
		contentPane.add(textFieldx2);
		
		textFieldy2 = new JTextField();
		textFieldy2.setEditable(false);
		textFieldy2.setFont(new Font("Arial", Font.PLAIN, 15));
		textFieldy2.setColumns(10);
		textFieldy2.setBounds(245, 101, 112, 48);
		contentPane.add(textFieldy2);
		
		
		
		resultField = new JTextField();
		resultField.setEditable(false);
		resultField.setBounds(101, 180, 214, 47);
		contentPane.add(resultField);
		resultField.setColumns(10);
		
		JButton btnC = new JButton("C");
		btnC.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnC.setForeground(Color.RED);
		btnC.setBackground(Color.LIGHT_GRAY);
		btnC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resultField.setText(null);
				textFieldx1.setText(null);
				textFieldy1.setText(null);
				textFieldx2.setText(null);
				textFieldy2.setText(null);
				multi_por.setText(null);
				count=0;
				textFieldx2.setVisible(true);
				textFieldy2.setVisible(true);
				lblVector.setVisible(true);
				lblNewLabel_2_1.setVisible(true);
				lblNewLabel_1.setVisible(true);
				lblNewLabel_2_1_1.setVisible(true);
				multi_por.setVisible(false);
				btnmultiescalar.setVisible(false);
				variX=0;
			}
		});
		btnC.setBounds(343, 182, 81, 39);
		contentPane.add(btnC);
		
		multi_por = new JTextField();
		multi_por.setEditable(false);
		multi_por.setBounds(122, 129, 168, 34);
		contentPane.add(multi_por);
		multi_por.setColumns(10);
		
		JButton atras = new JButton("back");
		atras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		atras.setBounds(213, 192, 89, 23);
		contentPane.add(atras);
		
		JButton btnHome = new JButton("HOME");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnHome.setForeground(Color.RED);
		btnHome.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnHome.setBackground(Color.LIGHT_GRAY);
		btnHome.setBounds(35, 437, 80, 51);
		contentPane.add(btnHome);
		multi_por.setVisible(false);
		
		
	}
}

