package Calculadora;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import javax.swing.text.DocumentFilter.FilterBypass;
import java.awt.Toolkit;

public class OperacionVectores extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField vec1pos2;
	private JTextField vec1pos1;
	private JTextField vec1pos3;
	private JLabel lblVector_1;
	private JTextField vec2pos1;
	private JTextField vec2pos2;
	private JTextField vec2pos3;
	private JTextField vec1pos4;
	private JTextField vec1pos5;
	private JTextField vec2pos4;
	private JTextField vec2pos5;
	private JLabel lblOperaciones;
	private JButton btnResta;
	private JButton btnMult;
	private JButton btnEsc;
	private JButton btnVect;
	private JLabel lblResult;
	private int cont1=0, result1, result2, result3, result4, result5, result6, result7, result8, result9, result10;
	private JTextField vec1pos6;
	private JTextField vec2pos6;
	private JTextField vec1pos7;
	private JTextField vec1pos9;
	private JTextField vec1pos8;
	private JTextField vec1pos10;
	private JTextField vec2pos7;
	private JTextField vec2pos8;
	private JTextField vec2pos9;
	private JTextField vec2pos10;
	private JTextField escalar;
	private JButton btnLimpiar;
	
	public static void main(String[] args) {
		try {
			OperacionVectores dialog = new OperacionVectores();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public OperacionVectores() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(OperacionVectores.class.getResource("/Dise\u00F1o/logo.jpg")));
		setBackground(new Color(60, 60, 60));
		setBounds(100, 100, 673, 400);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(60, 60, 60));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		setTitle("Calculadora de Vectores");
		setResizable(false);
		setLocationRelativeTo(null);

		
		JLabel lblNewLabel = new JLabel("  Ingrese los valores de los vectores:");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Meiryo", Font.BOLD, 13));
		lblNewLabel.setBounds(30, 43, 262, 20);
		contentPanel.add(lblNewLabel);
		
		JLabel lblCalculadora = new JLabel("CALCULADORA VECTORES");
		lblCalculadora.setForeground(new Color(255, 255, 255));
		lblCalculadora.setHorizontalAlignment(SwingConstants.CENTER);
		lblCalculadora.setFont(new Font("Meiryo", Font.BOLD, 17));
		lblCalculadora.setBounds(170, 11, 257, 20);
		contentPanel.add(lblCalculadora);
		
		JLabel lblVector = new JLabel("  Vector 1:");
		lblVector.setHorizontalAlignment(SwingConstants.CENTER);
		lblVector.setForeground(Color.WHITE);
		lblVector.setFont(new Font("Meiryo", Font.BOLD, 13));
		lblVector.setBounds(30, 84, 80, 20);
		contentPanel.add(lblVector);
		
		vec1pos1 = new JTextField();
		vec1pos1.setHorizontalAlignment(SwingConstants.CENTER);
		vec1pos1.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec1pos1.setColumns(10);
		vec1pos1.setBounds(107, 84, 50, 20);
		contentPanel.add(vec1pos1);
		
		vec1pos2 = new JTextField();
		vec1pos2.setHorizontalAlignment(SwingConstants.CENTER);
		vec1pos2.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec1pos2.setBounds(156, 84, 50, 20);
		contentPanel.add(vec1pos2);
		vec1pos2.setColumns(10);
		
		vec1pos3 = new JTextField();
		vec1pos3.setHorizontalAlignment(SwingConstants.CENTER);
		vec1pos3.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec1pos3.setColumns(10);
		vec1pos3.setBounds(204, 84, 50, 20);
		contentPanel.add(vec1pos3);
		
		vec1pos4 = new JTextField();
		vec1pos4.setHorizontalAlignment(SwingConstants.CENTER);
		vec1pos4.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec1pos4.setVisible(false);
		vec1pos4.setColumns(10);
		vec1pos4.setBounds(252, 84, 50, 20);
		contentPanel.add(vec1pos4);
		
		vec1pos5 = new JTextField();
		vec1pos5.setHorizontalAlignment(SwingConstants.CENTER);
		vec1pos5.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec1pos5.setVisible(false);
		vec1pos5.setColumns(10);
		vec1pos5.setBounds(301, 84, 50, 20);
		contentPanel.add(vec1pos5);
		
		vec1pos6 = new JTextField();
		vec1pos6.setHorizontalAlignment(SwingConstants.CENTER);
		vec1pos6.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec1pos6.setVisible(false);
		vec1pos6.setColumns(10);
		vec1pos6.setBounds(350, 84, 50, 20);
		contentPanel.add(vec1pos6);
		
		vec1pos7 = new JTextField();
		vec1pos7.setHorizontalAlignment(SwingConstants.CENTER);
		vec1pos7.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec1pos7.setVisible(false);
		vec1pos7.setColumns(10);
		vec1pos7.setBounds(399, 84, 50, 20);
		contentPanel.add(vec1pos7);
		
		vec1pos8 = new JTextField();
		vec1pos8.setHorizontalAlignment(SwingConstants.CENTER);
		vec1pos8.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec1pos8.setVisible(false);
		vec1pos8.setColumns(10);
		vec1pos8.setBounds(448, 84, 50, 20);
		contentPanel.add(vec1pos8);
		
		vec1pos9 = new JTextField();
		vec1pos9.setHorizontalAlignment(SwingConstants.CENTER);
		vec1pos9.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec1pos9.setVisible(false);
		vec1pos9.setColumns(10);
		vec1pos9.setBounds(497, 84, 50, 20);
		contentPanel.add(vec1pos9);
		
		vec1pos10 = new JTextField();
		vec1pos10.setHorizontalAlignment(SwingConstants.CENTER);
		vec1pos10.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec1pos10.setVisible(false);
		vec1pos10.setColumns(10);
		vec1pos10.setBounds(544, 84, 50, 20);
		contentPanel.add(vec1pos10);
		
		lblVector_1 = new JLabel("  Vector 2:");
		lblVector_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblVector_1.setForeground(Color.WHITE);
		lblVector_1.setFont(new Font("Meiryo", Font.BOLD, 13));
		lblVector_1.setBounds(30, 130, 80, 20);
		contentPanel.add(lblVector_1);
		
		vec2pos1 = new JTextField();
		vec2pos1.setHorizontalAlignment(SwingConstants.CENTER);
		vec2pos1.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec2pos1.setColumns(1);
		vec2pos1.setBounds(107, 130, 50, 20);
		contentPanel.add(vec2pos1);
		
		vec2pos2 = new JTextField();
		vec2pos2.setHorizontalAlignment(SwingConstants.CENTER);
		vec2pos2.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec2pos2.setColumns(10);
		vec2pos2.setBounds(156, 130, 50, 20);
		contentPanel.add(vec2pos2);
		
		vec2pos3 = new JTextField();
		vec2pos3.setHorizontalAlignment(SwingConstants.CENTER);
		vec2pos3.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec2pos3.setColumns(10);
		vec2pos3.setBounds(204, 130, 50, 20);
		contentPanel.add(vec2pos3);
		
		vec2pos4 = new JTextField();
		vec2pos4.setHorizontalAlignment(SwingConstants.CENTER);
		vec2pos4.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec2pos4.setVisible(false);
		vec2pos4.setColumns(10);
		vec2pos4.setBounds(252, 130, 50, 20);
		contentPanel.add(vec2pos4);
		
		vec2pos5 = new JTextField();
		vec2pos5.setHorizontalAlignment(SwingConstants.CENTER);
		vec2pos5.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec2pos5.setVisible(false);
		vec2pos5.setColumns(10);
		vec2pos5.setBounds(301, 130, 50, 20);
		contentPanel.add(vec2pos5);
		
		vec2pos6 = new JTextField();
		vec2pos6.setHorizontalAlignment(SwingConstants.CENTER);
		vec2pos6.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec2pos6.setVisible(false);
		vec2pos6.setColumns(10);
		vec2pos6.setBounds(350, 130, 50, 20);
		contentPanel.add(vec2pos6);
		
		vec2pos7 = new JTextField();
		vec2pos7.setHorizontalAlignment(SwingConstants.CENTER);
		vec2pos7.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec2pos7.setVisible(false);
		vec2pos7.setColumns(10);
		vec2pos7.setBounds(399, 130, 50, 20);
		contentPanel.add(vec2pos7);
		
		vec2pos8 = new JTextField();
		vec2pos8.setHorizontalAlignment(SwingConstants.CENTER);
		vec2pos8.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec2pos8.setVisible(false);
		vec2pos8.setColumns(10);
		vec2pos8.setBounds(448, 130, 50, 20);
		contentPanel.add(vec2pos8);
		
		vec2pos9 = new JTextField();
		vec2pos9.setHorizontalAlignment(SwingConstants.CENTER);
		vec2pos9.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec2pos9.setVisible(false);
		vec2pos9.setColumns(10);
		vec2pos9.setBounds(497, 130, 50, 20);
		contentPanel.add(vec2pos9);
		
		vec2pos10 = new JTextField();
		vec2pos10.setHorizontalAlignment(SwingConstants.CENTER);
		vec2pos10.setFont(new Font("Meiryo", Font.PLAIN, 11));
		vec2pos10.setVisible(false);
		vec2pos10.setColumns(10);
		vec2pos10.setBounds(544, 130, 50, 20);
		contentPanel.add(vec2pos10);
		
		DocumentFilter MaxCarac=new DocumentFilter() {
		    int maxCaracteres=5;
		    @Override
		    public void insertString(FilterBypass filt, int offset, String str, AttributeSet attr)
		            throws BadLocationException {
		        if ((filt.getDocument().getLength()+str.length())<maxCaracteres) {
		            super.insertString(filt, offset, str, attr);
		        }
		    }
		    @Override
		    public void replace(FilterBypass filt, int offset, int length, String str, AttributeSet attr)
		            throws BadLocationException {
		        if ((filt.getDocument().getLength()+str.length()-length)<=maxCaracteres) {
		            super.replace(filt, offset, length, str, attr);
		        }
		    }
		};
		((AbstractDocument) vec1pos1.getDocument()).setDocumentFilter(MaxCarac); ((AbstractDocument) vec1pos6.getDocument()).setDocumentFilter(MaxCarac); ((AbstractDocument) vec2pos1.getDocument()).setDocumentFilter(MaxCarac); ((AbstractDocument) vec2pos6.getDocument()).setDocumentFilter(MaxCarac);
		((AbstractDocument) vec1pos2.getDocument()).setDocumentFilter(MaxCarac); ((AbstractDocument) vec1pos7.getDocument()).setDocumentFilter(MaxCarac); ((AbstractDocument) vec2pos2.getDocument()).setDocumentFilter(MaxCarac); ((AbstractDocument) vec2pos7.getDocument()).setDocumentFilter(MaxCarac);
		((AbstractDocument) vec1pos3.getDocument()).setDocumentFilter(MaxCarac); ((AbstractDocument) vec1pos8.getDocument()).setDocumentFilter(MaxCarac); ((AbstractDocument) vec2pos3.getDocument()).setDocumentFilter(MaxCarac); ((AbstractDocument) vec2pos8.getDocument()).setDocumentFilter(MaxCarac);
		((AbstractDocument) vec1pos4.getDocument()).setDocumentFilter(MaxCarac); ((AbstractDocument) vec1pos9.getDocument()).setDocumentFilter(MaxCarac); ((AbstractDocument) vec2pos4.getDocument()).setDocumentFilter(MaxCarac); ((AbstractDocument) vec2pos9.getDocument()).setDocumentFilter(MaxCarac);
		((AbstractDocument) vec1pos5.getDocument()).setDocumentFilter(MaxCarac); ((AbstractDocument) vec1pos10.getDocument()).setDocumentFilter(MaxCarac); ((AbstractDocument) vec2pos5.getDocument()).setDocumentFilter(MaxCarac); ((AbstractDocument) vec2pos10.getDocument()).setDocumentFilter(MaxCarac);
		
		JButton RestElem = new JButton("-");       
		JButton SumElem = new JButton("+");
		SumElem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					cont1++;
					if(cont1==-1) {
						vec1pos2.setVisible(true);
						vec2pos2.setVisible(true);
						vec1pos2.setEnabled(true);
						vec2pos2.setEnabled(true);
						RestElem.setEnabled(true);
					}
					if(cont1==0) {
						vec1pos3.setVisible(true);
						vec2pos3.setVisible(true);
						vec1pos3.setEnabled(true);
						vec2pos3.setEnabled(true);
					}
					if(cont1==1) {
						vec1pos4.setVisible(true);
						vec2pos4.setVisible(true);
						vec1pos4.setEnabled(true);
						vec2pos4.setEnabled(true);
					}
					if(cont1==2) {
						vec1pos5.setVisible(true);
						vec2pos5.setVisible(true);
						vec1pos5.setEnabled(true);
						vec2pos5.setEnabled(true);
					}
					if(cont1==3) {
						vec1pos6.setVisible(true);
						vec2pos6.setVisible(true);
						vec1pos6.setEnabled(true);
						vec2pos6.setEnabled(true);
					}
					if(cont1==4) {
						vec1pos7.setVisible(true);
						vec2pos7.setVisible(true);
						vec1pos7.setEnabled(true);
						vec2pos7.setEnabled(true);
					}
					if(cont1==5) {
						vec1pos8.setVisible(true);
						vec2pos8.setVisible(true);
						vec1pos8.setEnabled(true);
						vec2pos8.setEnabled(true);
					}
					if(cont1==6) {
						vec1pos9.setVisible(true);
						vec2pos9.setVisible(true);
						vec1pos9.setEnabled(true);
						vec2pos9.setEnabled(true);
					}
					if(cont1==7) {
						vec1pos10.setVisible(true);
						vec2pos10.setVisible(true);
						vec1pos10.setEnabled(true);
						vec2pos10.setEnabled(true);
						SumElem.setEnabled(false);
					}
					if(cont1>0||cont1<0) {
						btnVect.setEnabled(false);
					}
					else {
						btnVect.setEnabled(true);
					}
			}
		});
		SumElem.setForeground(Color.WHITE);
		SumElem.setBackground(new Color(0, 139, 139));
		SumElem.setFont(new Font("Meiryo", Font.BOLD, 14));
		SumElem.setBounds(97, 161, 50, 22);
		contentPanel.add(SumElem);
		
		RestElem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cont1--;
				if(cont1==6) {
					vec1pos10.setVisible(false);
					vec2pos10.setVisible(false);
					vec1pos10.setEnabled(false);
					vec2pos10.setEnabled(false);
					SumElem.setEnabled(true);
				}
				if(cont1==5) {
					vec1pos9.setVisible(false);
					vec2pos9.setVisible(false);
					vec1pos9.setEnabled(false);
					vec2pos9.setEnabled(false);
				}
				if(cont1==4) {
					vec1pos8.setVisible(false);
					vec2pos8.setVisible(false);
					vec1pos8.setEnabled(false);
					vec2pos8.setEnabled(false);
				}
				if(cont1==3) {
					vec1pos7.setVisible(false);
					vec2pos7.setVisible(false);
					vec1pos7.setEnabled(false);
					vec2pos7.setEnabled(false);
				}
				if(cont1==2) {
					vec1pos6.setVisible(false);
					vec2pos6.setVisible(false);
					vec1pos6.setEnabled(false);
					vec2pos6.setEnabled(false);
				}
				if(cont1==1) {
					vec1pos5.setVisible(false);
					vec2pos5.setVisible(false);
					vec1pos5.setEnabled(false);
					vec2pos5.setEnabled(false);
				}
				if(cont1==0) {
					vec1pos4.setVisible(false);
					vec2pos4.setVisible(false);
					vec1pos4.setEnabled(false);
					vec2pos4.setEnabled(false);
				}
				if(cont1==-1) {
					vec1pos3.setVisible(false);
					vec2pos3.setVisible(false);
					vec1pos3.setEnabled(false);
					vec2pos3.setEnabled(false);
				}
				if(cont1==-2) {
					vec1pos2.setVisible(false);
					vec2pos2.setVisible(false);
					vec1pos2.setEnabled(false);
					vec2pos2.setEnabled(false);
					RestElem.setEnabled(false);
				}
				if(cont1>0||cont1<0) {
					btnVect.setEnabled(false);
				}
				else {
					btnVect.setEnabled(true);
				}
				
			}
		});
		RestElem.setForeground(Color.WHITE);
		RestElem.setFont(new Font("Meiryo UI", Font.BOLD, 14));
		RestElem.setBackground(new Color(0, 139, 139));
		RestElem.setBounds(156, 161, 50, 22);
		contentPanel.add(RestElem);
		
		lblOperaciones = new JLabel("  Operaciones:");
		lblOperaciones.setForeground(Color.WHITE);
		lblOperaciones.setHorizontalAlignment(SwingConstants.CENTER);
		lblOperaciones.setToolTipText("");
		lblOperaciones.setFont(new Font("Meiryo", Font.BOLD, 13));
		lblOperaciones.setBounds(30, 204, 119, 20);
		contentPanel.add(lblOperaciones);
		
		JLabel lblAux = new JLabel("");
		lblAux.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblAux.setBounds(10, 262, 544, 38);
		contentPanel.add(lblAux);
		
		JButton btnSuma = new JButton("SUMAR vector 1 y vector 2");
		btnSuma.setBackground(new Color(0, 139, 139));
		btnSuma.setForeground(Color.WHITE);
		btnSuma.setFont(new Font("Meiryo", Font.BOLD, 11));
		btnSuma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (btnSuma==e.getSource()) {
					lblAux.setText("");
		            int posi1=Integer.parseInt(vec1pos1.getText()), posiA=Integer.parseInt(vec2pos1.getText());
		            result1=posi1+posiA;
		            if (cont1>-3) {
		                lblResult.setText("Resultado: { "+result1+" }");
		            }
		            if(vec1pos2.isVisible()) {
		            	int posi2=Integer.parseInt(vec1pos2.getText()), posiB=Integer.parseInt(vec2pos2.getText());
			            result2=posi2+posiB;
			            if (cont1>-2) {
			                lblResult.setText("Resultado: { "+result1+";"+result2+" }");
			            }
		            }
		            if(vec1pos3.isVisible()) {
		            	int posi3=Integer.parseInt(vec1pos3.getText()), posiC=Integer.parseInt(vec2pos3.getText());
			            result3=posi3+posiC;
			            if (cont1>-1) {
			                lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+" }");
			            }
		            }
		            if(vec1pos4.isVisible()) {
		            	int posi4=Integer.parseInt(vec1pos4.getText()), posiD=Integer.parseInt(vec2pos4.getText());
			            result4=posi4+posiD;
			            if (cont1>0) {
			                lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+" }");
			            }
		            }
		            if(vec1pos5.isVisible()) {
		            	int posi5=Integer.parseInt(vec1pos5.getText()), posiE=Integer.parseInt(vec2pos5.getText());
			            result5=posi5+posiE;
			            if (cont1>1) {
			                lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+";"+result5+" }");
			            }
		            }
		            if(vec1pos6.isVisible()) {
		            	int posi6=Integer.parseInt(vec1pos6.getText()), posiF=Integer.parseInt(vec2pos6.getText());
			            result6=posi6+posiF;
			            if (cont1>2) {
			                lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+";"+result5+";"+result6+" }");
			            }
		            }    
			        if(vec1pos7.isVisible()) {
			            int posi7=Integer.parseInt(vec1pos7.getText()), posiG=Integer.parseInt(vec2pos7.getText());
				        result7=posi7+posiG;
				        if (cont1>3) {
				            lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+";"+result5+";"+result6+";"+result7+" }");
		                }
		            }
		            if(vec1pos8.isVisible()) {
		            	int posi8=Integer.parseInt(vec1pos8.getText()), posiH=Integer.parseInt(vec2pos8.getText());
		            	result8=posi8+posiH;
				        if (cont1>4) {
				            lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+";"+result5+";"+result6+";"+result7+";"+result8+" }");
			            }
		            }
		            if(vec1pos9.isVisible()) {
		            	int posi9=Integer.parseInt(vec1pos9.getText()), posiI=Integer.parseInt(vec2pos9.getText());
				        result9=posi9+posiI;
				        if (cont1>5) {
		                    lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+";"+result5+";"+result6+";"+result7+";"+result8+";"+result9+" }");
			            }
		            }
		            if(vec1pos10.isVisible()) {
		            	int posi10=Integer.parseInt(vec1pos10.getText()), posiJ=Integer.parseInt(vec2pos10.getText());
				        result10=posi10+posiJ;
				        if (cont1>6) {
			                lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+";"+result5+";"+result6+";"+result7+";"+result8+";"+result9+";"+result10+" }");
			            }
	                }
				}    
			}
		});
		btnSuma.setBounds(146, 204, 197, 23);
		contentPanel.add(btnSuma);
		
		btnResta = new JButton("RESTAR vector 1 y vector 2");
		btnResta.setForeground(Color.WHITE);
		btnResta.setBackground(new Color(0, 139, 139));
		btnResta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (btnResta==e.getSource()) {
					lblAux.setText("");
		            int posi1=Integer.parseInt(vec1pos1.getText()), posiA=Integer.parseInt(vec2pos1.getText());
		            result1=posi1-posiA;
		            if (cont1>-3) {
		                lblResult.setText("Resultado: { "+result1+" }");
		            }
		            if(vec1pos2.isVisible()) {
		            	int posi2=Integer.parseInt(vec1pos2.getText()), posiB=Integer.parseInt(vec2pos2.getText());
			            result2=posi2-posiB;
			            if (cont1>-2) {
			                lblResult.setText("Resultado: { "+result1+";"+result2+" }");
			            }
		            }
		            if(vec1pos3.isVisible()) {
		            	int posi3=Integer.parseInt(vec1pos3.getText()), posiC=Integer.parseInt(vec2pos3.getText());
			            result3=posi3-posiC;
			            if (cont1>-1) {
			                lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+" }");
			            }
		            }
		            if(vec1pos4.isVisible()) {
		            	int posi4=Integer.parseInt(vec1pos4.getText()), posiD=Integer.parseInt(vec2pos4.getText());
			            result4=posi4-posiD;
			            if (cont1>0) {
			                lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+" }");
			            }
		            }
		            if(vec1pos5.isVisible()) {
		            	int posi5=Integer.parseInt(vec1pos5.getText()), posiE=Integer.parseInt(vec2pos5.getText());
			            result5=posi5-posiE;
			            if (cont1>1) {
			                lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+";"+result5+" }");
			            }
		            }
		            if(vec1pos6.isVisible()) {
		            	int posi6=Integer.parseInt(vec1pos6.getText()), posiF=Integer.parseInt(vec2pos6.getText());
			            result6=posi6-posiF;
			            if (cont1>2) {
			                lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+";"+result5+";"+result6+" }");
			            }
		            }    
			        if(vec1pos7.isVisible()) {
			            int posi7=Integer.parseInt(vec1pos7.getText()), posiG=Integer.parseInt(vec2pos7.getText());
				        result7=posi7-posiG;
				        if (cont1>3) {
				            lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+";"+result5+";"+result6+";"+result7+" }");
		                }
		            }
		            if(vec1pos8.isVisible()) {
		            	int posi8=Integer.parseInt(vec1pos8.getText()), posiH=Integer.parseInt(vec2pos8.getText());
		            	result8=posi8-posiH;
				        if (cont1>4) {
				            lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+";"+result5+";"+result6+";"+result7+";"+result8+" }");
			            }
		            }
		            if(vec1pos9.isVisible()) {
		            	int posi9=Integer.parseInt(vec1pos9.getText()), posiI=Integer.parseInt(vec2pos9.getText());
				        result9=posi9-posiI;
				        if (cont1>5) {
		                    lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+";"+result5+";"+result6+";"+result7+";"+result8+";"+result9+" }");
			            }
		            }
		            if(vec1pos10.isVisible()) {
		            	int posi10=Integer.parseInt(vec1pos10.getText()), posiJ=Integer.parseInt(vec2pos10.getText());
				        result10=posi10-posiJ;
				        if (cont1>6) {
			                lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+";"+result5+";"+result6+";"+result7+";"+result8+";"+result9+";"+result10+" }");
			            }
	                }
				}
			}
		});
		btnResta.setFont(new Font("Meiryo", Font.BOLD, 11));
		btnResta.setBounds(364, 203, 197, 23);
		contentPanel.add(btnResta);
		
		btnMult = new JButton("Multiplicar vector 1 \r\npor un escalar:");
		btnMult.setForeground(Color.WHITE);
		btnMult.setBackground(new Color(0, 139, 139));
		btnMult.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (btnMult==e.getSource()) {
					lblAux.setText("");
					int esc=Integer.parseInt(escalar.getText());
		            int posi1=Integer.parseInt(vec1pos1.getText());
		            result1=posi1*esc;
		            if (cont1>-3) {
		                lblResult.setText("Resultado: { "+result1+" }");
		            }
		            if(vec1pos2.isVisible()) {
		            	int posi2=Integer.parseInt(vec1pos2.getText());
			            result2=posi2*esc;
			            if (cont1>-2) {
			                lblResult.setText("Resultado: { "+result1+";"+result2+" }");
			            }
		            }
		            if(vec1pos3.isVisible()) {
		            	int posi3=Integer.parseInt(vec1pos3.getText());
			            result3=posi3*esc;
			            if (cont1>-1) {
			                lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+" }");
			            }
		            }
		            if(vec1pos4.isVisible()) {
		            	int posi4=Integer.parseInt(vec1pos4.getText());
			            result4=posi4*esc;
			            if (cont1>0) {
			                lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+" }");
			            }
		            }
		            if(vec1pos5.isVisible()) {
		            	int posi5=Integer.parseInt(vec1pos5.getText());
			            result5=posi5*esc;
			            if (cont1>1) {
			                lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+";"+result5+" }");
			            }
		            }
		            if(vec1pos6.isVisible()) {
		            	int posi6=Integer.parseInt(vec1pos6.getText());
			            result6=posi6*esc;
			            if (cont1>2) {
			                lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+";"+result5+";"+result6+" }");
			            }
		            }    
			        if(vec1pos7.isVisible()) {
			            int posi7=Integer.parseInt(vec1pos7.getText());
				        result7=posi7*esc;
				        if (cont1>3) {
				            lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+";"+result5+";"+result6+";"+result7+" }");
		                }
		            }
		            if(vec1pos8.isVisible()) {
		            	int posi8=Integer.parseInt(vec1pos8.getText());
		            	result8=posi8*esc;
				        if (cont1>4) {
				            lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+";"+result5+";"+result6+";"+result7+";"+result8+" }");
			            }
		            }
		            if(vec1pos9.isVisible()) {
		            	int posi9=Integer.parseInt(vec1pos9.getText());
				        result9=posi9*esc;
				        if (cont1>5) {
		                    lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+";"+result5+";"+result6+";"+result7+";"+result8+";"+result9+" }");
			            }
		            }
		            if(vec1pos10.isVisible()) {
		            	int posi10=Integer.parseInt(vec1pos10.getText());
				        result10=posi10*esc;
				        if (cont1>6) {
			                lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+";"+result4+";"+result5+";"+result6+";"+result7+";"+result8+";"+result9+";"+result10+" }");
			            }
	                }
				}
			}
		});
		btnMult.setFont(new Font("Meiryo", Font.BOLD, 11));
		btnMult.setBounds(10, 238, 249, 23);
		contentPanel.add(btnMult);
		
		btnEsc = new JButton("Producto Escalar");
		btnEsc.setForeground(Color.WHITE);
		btnEsc.setBackground(new Color(0, 139, 139));
		btnEsc.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	if (btnEsc==e.getSource()) {
		            int posi1=Integer.parseInt(vec1pos1.getText()), posiA=Integer.parseInt(vec2pos1.getText());
		            result1=posi1*posiA;
		            if (cont1>-3) {
		                lblResult.setText("Resultado: { "+result1+" }");
		            }
		            if(vec1pos2.isVisible()) {
		            	int posi2=Integer.parseInt(vec1pos2.getText()), posiB=Integer.parseInt(vec2pos2.getText());
			            result2=posi2*posiB;
			            if (cont1>-2) {
			            	int aux1=result1+result2;
			            	lblAux.setText("<html>Elemento1="+result1+", Elemento2="+result2+"</html>");
			                lblResult.setText("Resultado: { "+aux1+" }");
			            }
		            }
		            if(vec1pos3.isVisible()) {
		            	int posi3=Integer.parseInt(vec1pos3.getText()), posiC=Integer.parseInt(vec2pos3.getText());
			            result3=posi3*posiC;
			            if (cont1>-1) {
			            	int aux1=result1+result2+result3;
			            	lblAux.setText("<html>Elemento1="+result1+", Elemento2="+result2+", Elemento3="+result3+"</html>");
			                lblResult.setText("Resultado: { "+aux1+" }");
			            }
		            }
		            if(vec1pos4.isVisible()) {
		            	int posi4=Integer.parseInt(vec1pos4.getText()), posiD=Integer.parseInt(vec2pos4.getText());
			            result4=posi4*posiD;
			            if (cont1>0) {
			            	int aux1=result1+result2+result3+result4;
			            	lblAux.setText("<html>Elemento1="+result1+", Elemento2="+result2+", Elemento3="+result3+", Elemento4="+result4+"</html>");
			                lblResult.setText("Resultado: { "+aux1+" }");
			            }
		            }
		            if(vec1pos5.isVisible()) {
		            	int posi5=Integer.parseInt(vec1pos5.getText()), posiE=Integer.parseInt(vec2pos5.getText());
			            result5=posi5*posiE;
			            if (cont1>1) {
			            	int aux1=result1+result2+result3+result4+result5;
			            	lblAux.setText("<html>Elemento1="+result1+", Elemento2="+result2+", Elemento3="+result3+", Elemento4="+result4+", Elemento5="+result5+"</html>");
			                lblResult.setText("Resultado: { "+aux1+" }");
			            }
		            }
		            if(vec1pos6.isVisible()) {
		            	int posi6=Integer.parseInt(vec1pos6.getText()), posiF=Integer.parseInt(vec2pos6.getText());
			            result6=posi6*posiF;
			            if (cont1>2) {
			            	int aux1=result1+result2+result3+result4+result5+result6;
			            	lblAux.setText("<html>Elemento1="+result1+", Elemento2="+result2+", Elemento3="+result3+", Elemento4="+result4+", Elemento5="+result5+"<br>Elemento6="+result6+"</html>");
			                lblResult.setText("Resultado: { "+aux1+" }");
			            }
		            }    
			        if(vec1pos7.isVisible()) {
			            int posi7=Integer.parseInt(vec1pos7.getText()), posiG=Integer.parseInt(vec2pos7.getText());
				        result7=posi7*posiG;
				        if (cont1>3) {
				        	int aux1=result1+result2+result3+result4+result5+result6+result7;
				        	lblAux.setText("<html>Elemento1="+result1+", Elemento2="+result2+", Elemento3="+result3+", Elemento4="+result4+", Elemento5="+result5+"<br>Elemento6="+result6+", Elemento7="+result7+"</html>");
			                lblResult.setText("Resultado: { "+aux1+" }");
		                }
		            }
		            if(vec1pos8.isVisible()) {
		            	int posi8=Integer.parseInt(vec1pos8.getText()), posiH=Integer.parseInt(vec2pos8.getText());
		            	result8=posi8*posiH;
				        if (cont1>4) {
				        	int aux1=result1+result2+result3+result4+result5+result6+result7+result8;
				        	lblAux.setText("<html>Elemento1="+result1+", Elemento2="+result2+", Elemento3="+result3+", Elemento4="+result4+", Elemento5="+result5+"<br>Elemento6="+result6+", Elemento7="+result7+", Elemento8="+result8+"</html>");
			                lblResult.setText("Resultado: { "+aux1+" }");
			            }
		            }
		            if(vec1pos9.isVisible()) {
		            	int posi9=Integer.parseInt(vec1pos9.getText()), posiI=Integer.parseInt(vec2pos9.getText());
				        result9=posi9*posiI;
				        if (cont1>5) {
				        	int aux1=result1+result2+result3+result4+result5+result6+result7+result8+result9;
				        	lblAux.setText("<html>Elemento1="+result1+", Elemento2="+result2+", Elemento3="+result3+", Elemento4="+result4+", Elemento5="+result5+"<br>Elemento6="+result6+", Elemento7="+result7+", Elemento8="+result8+", Elemento9="+result9+"</html>");
			                lblResult.setText("Resultado: { "+aux1+" }");
			            }
		            }
		            if(vec1pos10.isVisible()) {
		            	int posi10=Integer.parseInt(vec1pos10.getText()), posiJ=Integer.parseInt(vec2pos10.getText());
				        result10=posi10*posiJ;
				        if (cont1>6) {
				        	int aux1=result1+result2+result3+result4+result5+result6+result7+result8+result9+result10;
			                lblAux.setText("<html>Elemento1="+result1+", Elemento2="+result2+", Elemento3="+result3+", Elemento4="+result4+", Elemento5="+result5+"<br>Elemento6="+result6+", Elemento7="+result7+", Elemento8="+result8+", Elemento9="+result9+", Elemento10="+result10+"</html>");
			                lblResult.setText("Resultado: { "+aux1+" }");
				        }
	                }
				}
		    }
		});
		btnEsc.setFont(new Font("Meiryo", Font.BOLD, 11));
		btnEsc.setBounds(325, 238, 152, 23);
		contentPanel.add(btnEsc);
		
		btnVect = new JButton("Producto Vectorial");
		btnVect.setForeground(Color.WHITE);
		btnVect.setBackground(new Color(0, 139, 139));
		btnVect.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	lblAux.setText("");
	            if(vec1pos3.isVisible()) {
	            	int posi1=Integer.parseInt(vec1pos1.getText()), posiA=Integer.parseInt(vec2pos1.getText());
			    	int posi2=Integer.parseInt(vec1pos2.getText()), posiB=Integer.parseInt(vec2pos2.getText());
			    	int posi3=Integer.parseInt(vec1pos3.getText()), posiC=Integer.parseInt(vec2pos3.getText());
	        		result1=(posi2*posiC)-(posiB*posi3);
					result2=-((posi1*posiC)-(posiA*posi3));
					result3=(posi1*posiB)-(posiA*posi2);
		            if (cont1>-1) {
		            	lblResult.setText("Resultado: { "+result1+";"+result2+";"+result3+" }");
		            }
	            }
		    }
		});
		btnVect.setFont(new Font("Meiryo", Font.BOLD, 11));
		btnVect.setBounds(497, 238, 152, 23);
		contentPanel.add(btnVect);
		
		lblResult = new JLabel("Resultado:");
		lblResult.setForeground(Color.WHITE);
		lblResult.setFont(new Font("Meiryo", Font.BOLD, 13));
		lblResult.setBounds(10, 295, 584, 22);
		contentPanel.add(lblResult);
		
		escalar = new JTextField();
		escalar.setHorizontalAlignment(SwingConstants.CENTER);
		escalar.setFont(new Font("Meiryo", Font.PLAIN, 13));
		escalar.setBounds(252, 238, 50, 23);
		contentPanel.add(escalar);
		escalar.setColumns(10);
		
		JButton btnNewButton = new JButton("Volver");
		btnNewButton.setFont(new Font("Meiryo", Font.BOLD, 11));
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(new Color(0, 139, 139));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OperacionVectores.this.setVisible(false);
				Menu.main(new String [] {});
			}
		});
		btnNewButton.setBounds(182, 327, 89, 23);
		contentPanel.add(btnNewButton);
		
		btnLimpiar = new JButton("Limpiar");
		btnLimpiar.setFont(new Font("Meiryo", Font.BOLD, 11));
		btnLimpiar.setForeground(Color.WHITE);
		btnLimpiar.setBackground(new Color(0, 139, 139));
		btnLimpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				vec1pos1.setText("");
				vec1pos2.setText("");
				vec1pos3.setText("");
				vec1pos4.setText("");
				vec1pos5.setText("");
				vec1pos6.setText("");
				vec1pos7.setText("");
				vec1pos8.setText("");
				vec1pos9.setText("");
				vec1pos10.setText("");
				vec2pos1.setText("");
				vec2pos2.setText("");
				vec2pos3.setText("");
				vec2pos4.setText("");
				vec2pos5.setText("");
				vec2pos6.setText("");
				vec2pos7.setText("");
				vec2pos8.setText("");
				vec2pos9.setText("");
				vec2pos10.setText("");
				escalar.setText("");
				lblResult.setText("Resultado: ");
			}
		});
		btnLimpiar.setBounds(320, 328, 89, 23);
		contentPanel.add(btnLimpiar);
	}
}