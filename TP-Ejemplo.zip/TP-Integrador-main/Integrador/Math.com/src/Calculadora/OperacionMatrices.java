package Calculadora;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.JDialog;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class OperacionMatrices extends JDialog {
	private final JPanel contentPanel = new JPanel();
	private JTextField[][] textFields;
    private JTextField[][] textFields1;
    private JTextField[][] text;
    private JTextField[][] texto;
    private JTextField textField;
    Choice columA = new Choice();
    Choice columB = new Choice();
    Choice rowA = new Choice();
    Choice rowB = new Choice();
    private JButton btnDeterminante;
    private JButton btnSumar;
    private JButton btnNewButton;
    private JButton btnNewButton_1;
    private JButton btnNewButton_2;
    private JButton btnNewButton_3;
    private JButton btnNewButton_4;
    private int colum1,colum2,row1,row2;
    private JLabel lblNewLabel;
    private JLabel lblMatrizB;
    private JLabel lblResultados;
    private JButton btnVolver;

	public static void main(String[] args) {
		try {
			OperacionMatrices dialog = new OperacionMatrices();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public OperacionMatrices() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(OperacionMatrices.class.getResource("/Dise\u00F1o/logo.jpg")));
		setBackground(new Color(60, 60, 60));
		setBounds(100, 100, 1075, 325);
		setTitle("Calculadora de Matrices");
		contentPanel.setBackground(new Color(60, 60, 60));
		contentPanel.setLayout(null);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);

		setResizable(false);
		setLocationRelativeTo(null);
		columA.setFont(new Font("Meiryo", Font.PLAIN, 9));

        
		columA.addItem("Columnas");
        columB.setFont(new Font("Meiryo", Font.PLAIN, 9));
        columB.addItem("Columnas");
        rowA.setFont(new Font("Meiryo", Font.PLAIN, 9));
        rowA.addItem("Filas");
        rowB.setFont(new Font("Meiryo", Font.PLAIN, 9));
        rowB.addItem("Filas");
        for (int i = 0; i < 5; i++) {
            rowA.addItem("" + (i + 1));
            columA.addItem("" + (i + 1));
            rowB.addItem("" + (i + 1));
            columB.addItem("" + (i + 1));
        }
        columB.setBounds(449, 221, 70, 20);
        columA.setBounds(96, 221, 70, 20);
        rowB.setBounds(373, 221, 70, 20); 
        rowA.setBounds(20, 221, 70, 20);
        contentPanel.add(columA);
        contentPanel.add(columB);
        contentPanel.add(rowA);
        contentPanel.add(rowB);
    
        columB.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
            	if (e.getStateChange() == ItemEvent.SELECTED) {
            	colum2 = Integer.parseInt(columB.getSelectedItem());
            	createTextFields();	
            	}
            }
        });

        columA.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
            	if (e.getStateChange() == ItemEvent.SELECTED) {
            	colum1 = Integer.parseInt(columA.getSelectedItem());
            	createTextFields();
            	}
            }
        });

        rowB.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
            	if (e.getStateChange() == ItemEvent.SELECTED) {
            	 row2 = Integer.parseInt(rowB.getSelectedItem());
            	 createTextFields();
            	 }
            }
        });

        rowA.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
            	if (e.getStateChange() == ItemEvent.SELECTED) {
            	 row1 = Integer.parseInt(rowA.getSelectedItem());
            	 createTextFields();
            	 }
            }
        });
               
        btnDeterminante = new JButton("Determinante A");
        btnDeterminante.setForeground(Color.WHITE);
        btnDeterminante.setFont(new Font("Meiryo", Font.BOLD, 11));
        btnDeterminante.setBackground(new Color(0, 139, 139));
        btnDeterminante.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                double[][] matrix1 = getMatrixFromTextFields();
                if(row1==colum1) {
                double determinant = calculateDeterminant(matrix1);
                JOptionPane.showMessageDialog(null, "El determinante de A es: " + determinant);	
                }else {
                	JOptionPane.showMessageDialog(null,"No se puede realizar la determinante por que no es una matriz cuadrada");
                }
            }
        });
        btnDeterminante.setBounds(20, 245, 146, 30);
        contentPanel.add(btnDeterminante);

        btnSumar = new JButton("A+B");
        btnSumar.setForeground(Color.WHITE);
        btnSumar.setFont(new Font("Meiryo", Font.BOLD, 11));
        btnSumar.setBackground(new Color(0, 139, 139));
        btnSumar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                double[][] matrix1 = getMatrixFromTextFields();
                double[][] matrix2 = getMatrixFromTextField();
                if(colum1==row1&&colum2==row2&&row1==colum2) {
                    double[][] result = sumMatri(matrix1, matrix2);
                    displayMatrixInTextFields(result);	
                }else {
                	JOptionPane.showMessageDialog(null,"No se pueden sumar las matrices");
                }
            }
        });
        btnSumar.setBounds(176, 245, 100, 30);
        contentPanel.add(btnSumar);
        
        btnNewButton = new JButton("A-B");
        btnNewButton.setFont(new Font("Meiryo", Font.BOLD, 11));
        btnNewButton.setForeground(Color.WHITE);
        btnNewButton.setBackground(new Color(0, 139, 139));
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		double[][] matrix1 = getMatrixFromTextFields();
                double[][] matrix2 = getMatrixFromTextField();
                if(colum1==row1&&colum2==row2&&row1==colum2) {
                double[][] result = restMatri(matrix1, matrix2);
                displayMatrixInTextFields(result);	
                }else {
                	JOptionPane.showMessageDialog(null,"No se pueden restar las matrices");
                }
             }
        });
        btnNewButton.setBounds(286, 245, 100, 30);
        contentPanel.add(btnNewButton);
        
        btnNewButton_1 = new JButton("AxB");
        btnNewButton_1.setForeground(Color.WHITE);
        btnNewButton_1.setFont(new Font("Meiryo", Font.BOLD, 11));
        btnNewButton_1.setBackground(new Color(0, 139, 139));
        btnNewButton_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		double[][] matrix1 = getMatrixFromTextFields();
                double[][] matrix2 = getMatrixFromTextField();
                if(colum1!=row2) {
                	JOptionPane.showMessageDialog(null,"No se pueden multiplicar las matrices");
                }else {
                	double[][] result = multiplicMatrix(matrix1, matrix2);
                    displayMatrixInTextFields(result);
                }
        	}
        });
        btnNewButton_1.setBounds(393, 245, 100, 30);
        contentPanel.add(btnNewButton_1);
        
        btnNewButton_2 = new JButton("Inversa A");
        btnNewButton_2.setFont(new Font("Meiryo", Font.BOLD, 11));
        btnNewButton_2.setForeground(Color.WHITE);
        btnNewButton_2.setBackground(new Color(0, 139, 139));
        btnNewButton_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		double[][] matrix1 = getMatrixFromTextFields();
        		double determ=calculateDeterminant(matrix1);
        		if(colum1==row1 && determ!=0) {
        		double[][] result = inverMatrix(matrix1);
        		displayMatrixInTextFields(result);
        	    }else if(colum1!=row1){
        	    	JOptionPane.showMessageDialog(null,"No se puede realizar la inversa de la matriz A");
        	    }else if(determ==0) {
        	    	JOptionPane.showMessageDialog(null,"No se puede realizar la inversa de la matriz A");
        	    }
             }
        });
        btnNewButton_2.setBounds(503, 245, 100, 30);
        contentPanel.add(btnNewButton_2);
        
        btnNewButton_3 = new JButton("A x Escalar");
        btnNewButton_3.setFont(new Font("Meiryo", Font.BOLD, 11));
        btnNewButton_3.setForeground(Color.WHITE);
        btnNewButton_3.setBackground(new Color(0, 139, 139));
        btnNewButton_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		textoCrate();
                int escal= Integer.parseInt(textField.getText());
        		double[][] matrix1 = getMatrixFromTextFields();
        		double[][] result = multiplicScalar(matrix1,escal);
        		
                for (int i = 0; i < row1; i++) {
                    for (int j = 0; j < colum1; j++) {
                        texto[i][j].setText(String.valueOf(result[i][j]));
                    }
                }
        	}
        });
        btnNewButton_3.setBounds(723, 245, 113, 30);
        contentPanel.add(btnNewButton_3);
        
        btnNewButton_4 = new JButton("A/B");
        btnNewButton_4.setForeground(Color.WHITE);
        btnNewButton_4.setFont(new Font("Meiryo", Font.BOLD, 11));
        btnNewButton_4.setBackground(new Color(0, 139, 139));
        btnNewButton_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		double[][] matrix1 = getMatrixFromTextFields();
                double[][] matrix2 = getMatrixFromTextField();
                double determ=calculateDeterminant(matrix2);
                if(determ!=0&&colum2==row2&&row2==colum1) {
                double[][] result = diviMatrix(matrix1, matrix2);
                displayMatrixInTextFields(result);
                }else {
        	    	JOptionPane.showMessageDialog(null,"No se puede realizar la inversa de la matriz B");
        	    }
        	}
        });
        btnNewButton_4.setBounds(613, 245, 100, 30);
        contentPanel.add(btnNewButton_4);
        
        textField = new JTextField();
        textField.setHorizontalAlignment(SwingConstants.CENTER);
        textField.setFont(new Font("Meiryo", Font.PLAIN, 11));
        textField.setBounds(834, 245, 84, 30);
        contentPanel.add(textField);
        textField.setColumns(10);
        
        lblNewLabel = new JLabel("Matriz A");
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setForeground(Color.WHITE);
        lblNewLabel.setBounds(106, 11, 120, 35);
        lblNewLabel.setFont(new Font("Meiryo", Font.BOLD, 25));
        lblNewLabel.setToolTipText("");
        contentPanel.add(lblNewLabel);
        
        lblMatrizB = new JLabel("Matriz B");
        lblMatrizB.setHorizontalAlignment(SwingConstants.CENTER);
        lblMatrizB.setForeground(Color.WHITE);
        lblMatrizB.setBounds(421, 11, 120, 35);
        lblMatrizB.setToolTipText("");
        lblMatrizB.setFont(new Font("Meiryo", Font.BOLD, 25));
        contentPanel.add(lblMatrizB);
        
        lblResultados = new JLabel("Resultados");
        lblResultados.setForeground(Color.WHITE);
        lblResultados.setHorizontalAlignment(SwingConstants.CENTER);
        lblResultados.setBounds(807, 11, 153, 35);
        lblResultados.setToolTipText("");
        lblResultados.setFont(new Font("Meiryo", Font.BOLD, 25));
        contentPanel.add(lblResultados);
        
        btnVolver = new JButton("Volver");
        btnVolver.setForeground(Color.WHITE);
        btnVolver.setFont(new Font("Meiryo", Font.BOLD, 11));
        btnVolver.setBackground(new Color(0, 139, 139));
        btnVolver.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		OperacionMatrices.this.setVisible(false);
        		Menu.main(new String [] {});
        	}
        });
        btnVolver.setBounds(960, 245, 89, 27);
        contentPanel.add(btnVolver);
    }
   private void textoCrate() {
	   texto = new JTextField[row1][colum1];
       for (int i = 0; i < row1; i++) {
           for (int j = 0; j < colum1; j++) {
               texto[i][j] = new JTextField();
               texto[i][j].setBounds(750 + j * 60, 60 + i * 30, 50, 20);
               contentPanel.add(texto[i][j]);
           }
       }
       for(int i=0;i<row1;i++) {
       	for(int j=0;j<colum1;j++) {
       		texto[i][j].setEditable(false);
       	}
       }
   }
    private void createTextFields() {
        contentPanel.removeAll();
        contentPanel.add(lblMatrizB);
        contentPanel.add(lblNewLabel);
        contentPanel.add(lblResultados);
        contentPanel.add(columA);
        contentPanel.add(columB);
        contentPanel.add(rowA);
        contentPanel.add(rowB);
        contentPanel.add(btnDeterminante);
        contentPanel.add(btnSumar);
        contentPanel.add(btnNewButton);
        contentPanel.add(btnNewButton_1);
        contentPanel.add(btnNewButton_2);
        contentPanel.add(btnNewButton_3);
        contentPanel.add(btnNewButton_4);
        contentPanel.add(textField);
        contentPanel.add(btnVolver);

        textFields = new JTextField[row1][colum1];
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < colum1; j++) {
                textFields[i][j] = new JTextField();
                textFields[i][j].setBounds(20 + j * 60, 60 + i * 30, 50, 20);
                contentPanel.add(textFields[i][j]);
            }
        }

        textFields1 = new JTextField[row2][colum2];
        for (int i = 0; i < row2; i++) {
            for (int j = 0; j < colum2; j++) {
                textFields1[i][j] = new JTextField();
                textFields1[i][j].setBounds(350 + j * 60, 60 + i * 30, 50, 20);
                contentPanel.add(textFields1[i][j]);
            }
        }

        text = new JTextField[row1][colum2];
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < colum2; j++) {
                text[i][j] = new JTextField();
                text[i][j].setBounds(750 + j * 60, 60 + i * 30, 50, 20);
                contentPanel.add(text[i][j]);
            }
        }
        for(int i=0;i<row1;i++) {
        	for(int j=0;j<colum2;j++) {
        		text[i][j].setEditable(false);
        	}
        }
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    private double[][] getMatrixFromTextFields() {
        double[][] matrix1 = new double[row1][colum1];
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < colum1; j++) {
                String text = textFields[i][j].getText();
                try {
                    matrix1[i][j] = Double.parseDouble(text);
                } catch (NumberFormatException e) {
                    matrix1[i][j] = 0;
                }
            }
        }
        return matrix1;
    }

    private double[][] getMatrixFromTextField() {
        double[][] matrix2 = new double[row2][colum2];
        for (int i = 0; i < row2; i++) {
            for (int j = 0; j < colum2; j++) {
                String text = textFields1[i][j].getText();
                try {
                    matrix2[i][j] = Double.parseDouble(text);
                } catch (NumberFormatException e) {
                    matrix2[i][j] = 0;
                }
            }
        }
        return matrix2;
    }

    private void displayMatrixInTextFields(double[][] matrix) {
        int rows = matrix.length;
        int columns = matrix[0].length;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                text[i][j].setText(String.valueOf(matrix[i][j]));
            }
        }
    }
    public static double calculateDeterminant(double[][] matrix) {
    	 int n = matrix.length;

         if (n == 2) {
             return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
         } else {
             double determinant = 0;

             for (int j = 0; j < n; j++) {
                 double[][] submatrix = new double[n - 1][n - 1];

                 for (int i = 1; i < n; i++) {
                     for (int k = 0; k < n; k++) {
                         if (k < j) {
                             submatrix[i - 1][k] = matrix[i][k];
                         } else if (k > j) {
                             submatrix[i - 1][k - 1] = matrix[i][k];
                         }
                     }
                 }

                 determinant += Math.pow(-1, j) * matrix[0][j] * calculateDeterminant(submatrix);
             }

             return determinant;
         }
    }

    public static double[][] sumMatri(double[][] matrix1, double[][] matrix2) {
    	int columns = matrix2.length;
        int rows = matrix2[0].length;
    	double[][] result = new double[rows][columns];
	    for (int i = 0; i < rows; i++) {
	        for (int j = 0; j < columns; j++) {
	            result[i][j] = matrix1[i][j] + matrix2[i][j];
	        }
	    }
	    return result;
    }
    public static double[][] restMatri(double[][] matrix1, double[][] matrix2) {
    	int columns = matrix2.length;
        int rows = matrix2[0].length;
    	double[][] result = new double[rows][columns];
	    for (int i = 0; i < rows; i++) {
	        for (int j = 0; j < columns; j++) {
	            result[i][j] = matrix1[i][j] - matrix2[i][j];
	        }
	    }
	    return result;
    }
    public static double[][] multiplicMatrix(double[][] matrix1, double[][] matrix2) {
        int rows1 = matrix1.length;
        int columns1 = matrix1[0].length;
        int rows2 = matrix2.length;
        int columns2 = matrix2[0].length;

        double[][] result = new double[rows1][columns2];

        for (int i = 0; i < rows1; i++) {
            for (int j = 0; j < columns2; j++) {
                double sum = 0;

                for (int k = 0; k < columns1; k++) {
                    sum += matrix1[i][k] * matrix2[k][j];
                }

                result[i][j] = sum;
            }
        }
        return result;
    }
 
    public static double[][] multiplicScalar(double[][] matrix1, int escal) {
        int columns = matrix1.length;
        int rows = matrix1[0].length;
        double[][] result = new double[columns][rows];
        for (int i = 0; i < columns; i++) {
            for (int j = 0; j < rows; j++) {
                result[i][j] = matrix1[i][j] * escal;
            }
        }
        return result;
    }
    public static double[][] inverMatrix(double[][] matrix1){
    	int columns = matrix1.length;
        int rows = matrix1[0].length;
        double[][] adjMatrix= new double[rows][columns];
    	double[][] result = new double[rows][columns];
    	double determ= calculateDeterminant(matrix1);
    	if(determ!=0) {
    		for (int i = 0; i < rows; i++) {
                for (int j = i + 1; j < columns; j++) {
                    double m_temp = matrix1[i][j];
                    matrix1[i][j] = matrix1[j][i];
                    matrix1[j][i] = m_temp;
                }
            }

            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < columns; j++) {
                	adjMatrix[i][j] = (matrix1[(i + 1) % 3][(j + 1) % 3] * matrix1[(i + 2) % 3][(j + 2) % 3])
                            - (matrix1[(i + 2) % 3][(j + 1) % 3] * matrix1[(i + 1) % 3][(j + 2) % 3]);
                    result[i][j] = adjMatrix[i][j] * (1 / determ);
                }
            }
    	}
    	return result;
    }
    public static double[][] diviMatrix(double[][] matrix1,double[][] matrix2){
    	int columns = matrix2.length;
        int rows = matrix2[0].length;
    	double[][] result = new double[rows][columns];
    	double[][] inver= inverMatrix(matrix2);
    	result= multiplicMatrix(matrix1,inver);
    	return result;
    }
}