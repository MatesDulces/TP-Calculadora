package Calculadora;

import javax.swing.*;
import java.awt.event.*;
import java.lang.Math;
import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Toolkit;

public class OperacionComun extends JDialog{

	private final JPanel contentPanel = new JPanel();
	private JTextField textNro1;
	private JTextField textNro2;
	JButton btnSuma,btnResta, btnMultiplicacion, btnDivision, btnPotencia, btnRaizCuadrada, btnRaizCubica; 
	private JLabel lblResultado;
	private JButton volver;
	private JButton btnLimpiar;
	
	public static void main(String[] args) {
		try {
			OperacionComun dialog = new OperacionComun();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public OperacionComun() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(OperacionComun.class.getResource("/Dise\u00F1o/logo.jpg")));
		setBackground(new Color(60, 60, 60));
		
		iniciarVentana();
		
		setTitle("Calculadora Basica");
		setResizable(false);
		setLocationRelativeTo(null);
	}

	private void iniciarVentana() {
		setBounds(100, 100, 406, 351);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(60, 60, 60));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblTitulo = new JLabel("OPERACIONES MATEMATICAS");
		lblTitulo.setForeground(Color.WHITE);
		lblTitulo.setBackground(new Color(60, 60, 60));
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setFont(new Font("Meiryo", Font.BOLD, 18));
		lblTitulo.setBounds(0, 0, 384, 44);
		contentPanel.add(lblTitulo);
		
		textNro1 = new JTextField();
		textNro1.setFont(new Font("Meiryo", Font.PLAIN, 15));
		textNro1.setHorizontalAlignment(SwingConstants.CENTER);
		textNro1.setBounds(160, 61, 62, 20);
		contentPanel.add(textNro1);
		textNro1.setColumns(10);
		
		JLabel lblNumero1 = new JLabel("Numero 1:");
		lblNumero1.setForeground(Color.WHITE);
		lblNumero1.setFont(new Font("Meiryo", Font.BOLD, 15));
		lblNumero1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNumero1.setBounds(50, 60, 100, 20);
		contentPanel.add(lblNumero1);
		
		textNro2 = new JTextField();
		textNro2.setFont(new Font("Meiryo", Font.PLAIN, 15));
		textNro2.setHorizontalAlignment(SwingConstants.CENTER);
		textNro2.setColumns(10);
		textNro2.setBounds(160, 92, 62, 20);
		contentPanel.add(textNro2);
		
		JLabel lblNumero2 = new JLabel("Numero 2:");
		lblNumero2.setFont(new Font("Meiryo", Font.BOLD, 15));
		lblNumero2.setForeground(Color.WHITE);
		lblNumero2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNumero2.setBounds(50, 91, 100, 20);
		contentPanel.add(lblNumero2);
		
		btnSuma = new JButton("SUMA");
		btnSuma.setForeground(Color.WHITE);
		btnSuma.setFont(new Font("Meiryo", Font.BOLD, 11));
		btnSuma.setBackground(new Color(0, 139, 139));
		btnSuma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				float num1 = Float.parseFloat(textNro1.getText());
				float num2 = Float.parseFloat(textNro2.getText());
				float suma = num1 + num2;
				lblResultado.setText("La suma es "+suma);
			}
		});
		btnSuma.setBounds(273, 55, 89, 23);
		contentPanel.add(btnSuma);
		
		btnResta = new JButton("RESTA");
		btnResta.setForeground(Color.WHITE);
		btnResta.setFont(new Font("Meiryo", Font.BOLD, 11));
		btnResta.setBackground(new Color(0, 139, 139));
		btnResta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				float num1 = Float.parseFloat(textNro1.getText());
				float num2 = Float.parseFloat(textNro2.getText());
				float resta = num1-num2;
				lblResultado.setText("La resta es "+resta);
			}
		});
		btnResta.setBounds(273, 89, 89, 23);
		contentPanel.add(btnResta);
		
		btnMultiplicacion = new JButton("MULT");
		btnMultiplicacion.setForeground(Color.WHITE);
		btnMultiplicacion.setFont(new Font("Meiryo", Font.BOLD, 11));
		btnMultiplicacion.setBackground(new Color(0, 139, 139));
		btnMultiplicacion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				float num1 = Float.parseFloat(textNro1.getText());
				float num2 = Float.parseFloat(textNro2.getText());
				float mult = num1 * num2;
				lblResultado.setText("La multiplicacion es "+mult);
			}
		});
		btnMultiplicacion.setBounds(273, 123, 89, 23);
		contentPanel.add(btnMultiplicacion);
		
		btnDivision = new JButton("DIVISION");
		btnDivision.setForeground(Color.WHITE);
		btnDivision.setFont(new Font("Meiryo", Font.BOLD, 11));
		btnDivision.setBackground(new Color(0, 139, 139));
		btnDivision.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				float num1 = Float.parseFloat(textNro1.getText());
				float num2 = Float.parseFloat(textNro2.getText());
				float div=0;
				if(num2!=0)
				{
					div=num1/num2;
					lblResultado.setText("La division es "+div);
				}
				else
				{
					lblResultado.setText("No se puede dividir por 0");
				}
			}
		});
		btnDivision.setBounds(24, 123, 100, 23);
		contentPanel.add(btnDivision);
		
		btnPotencia = new JButton("POTENCIA");
		btnPotencia.setForeground(Color.WHITE);
		btnPotencia.setFont(new Font("Meiryo", Font.BOLD, 11));
		btnPotencia.setBackground(new Color(0, 139, 139));
		btnPotencia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				float num1 = Float.parseFloat(textNro1.getText());
				float num2 = Float.parseFloat(textNro2.getText());
				float pot = (float) Math.pow(num1, num2);
				lblResultado.setText("La potencia de "+num1+" a "+num2+" es "+pot);
			}
		});
		btnPotencia.setBounds(146, 123, 100, 23);
		contentPanel.add(btnPotencia);
		
		btnRaizCuadrada = new JButton("RAIZ CUADRADA");
		btnRaizCuadrada.setForeground(Color.WHITE);
		btnRaizCuadrada.setFont(new Font("Meiryo", Font.BOLD, 11));
		btnRaizCuadrada.setBackground(new Color(0, 139, 139));
		btnRaizCuadrada.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				float num1 = Float.parseFloat(textNro1.getText());
				float raiz2 = (float) Math.sqrt(num1);
				lblResultado.setText("La raiz cuadrada de"+num1+" es "+raiz2);
			}
		});
		btnRaizCuadrada.setBounds(50, 157, 135, 23);
		contentPanel.add(btnRaizCuadrada);
		
		btnRaizCubica = new JButton("RAIZ CUBICA");
		btnRaizCubica.setForeground(Color.WHITE);
		btnRaizCubica.setFont(new Font("Meiryo", Font.BOLD, 11));
		btnRaizCubica.setBackground(new Color(0, 139, 139));
		btnRaizCubica.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				float num1 = Float.parseFloat(textNro1.getText());
				float raiz3 = (float) Math.cbrt(num1);
				lblResultado.setText("La raiz cubica de "+num1+" es "+raiz3);
			}
		});
		btnRaizCubica.setBounds(205, 157, 124, 23);
		contentPanel.add(btnRaizCubica);
		
		lblResultado = new JLabel(" RESULTADO: ");
		lblResultado.setForeground(Color.WHITE);
		lblResultado.setFont(new Font("Meiryo", Font.BOLD, 15));
		lblResultado.setBounds(0, 215, 390, 20);
		contentPanel.add(lblResultado);
		
		volver = new JButton("Volver");
		volver.setForeground(Color.WHITE);
		volver.setBackground(new Color(0, 139, 139));
		volver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OperacionComun.this.setVisible(false);
				Menu.main(new String [] {});
			}
		});
		volver.setFont(new Font("Meiryo", Font.BOLD, 11));
		volver.setBounds(82, 274, 89, 27);
		contentPanel.add(volver);
		
		btnLimpiar = new JButton("Limpiar");
		btnLimpiar.setForeground(Color.WHITE);
		btnLimpiar.setFont(new Font("Meiryo", Font.BOLD, 11));
		btnLimpiar.setBackground(new Color(0, 139, 139));
		btnLimpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lblResultado.setText("  RESULTADO: ");
				textNro1.setText("");
				textNro2.setText("");
			}
		});
		btnLimpiar.setBounds(228, 274, 89, 27);
		contentPanel.add(btnLimpiar);
	}
}