package Calculadora;

import javax.swing.*;
import java.awt.event.*;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import java.awt.Color;

public class Principal extends JFrame //implements ActionListener
{
	private JPanel contentPane;
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					Principal frame = new Principal();
					frame.setVisible(true);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	public Principal() 
	{
		setForeground(new Color(36, 36, 36));
		setBackground(new Color(36, 36, 36));
		setIconImage(Toolkit.getDefaultToolkit().getImage(Principal.class.getResource("/Dise\u00F1o/logo.jpg")));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 550, 400);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(36, 36, 36));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		setTitle("Calculadora");  //pone titulo a la ventana
		setResizable(false); //no se puede agrandar o achicar
		setLocationRelativeTo(null);
		
		JButton comenzar = new JButton("Comenzar");
		comenzar.setForeground(new Color(255, 255, 255));
		comenzar.setBackground(new Color(0, 139, 139));
		comenzar.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				Menu dialog = new Menu(); //new javax.swing.JFrame(), true
				dialog.setLocationRelativeTo(null);
				dialog.setVisible(true);
				Principal.this.setVisible(false);
			}
		});
		comenzar.setFont(new Font("Meiryo", Font.BOLD, 30));
		comenzar.setBounds(170, 246, 198, 43);
		contentPane.add(comenzar);
		
		JLabel fondo = new JLabel("New label");
		fondo.setIcon(new ImageIcon(Principal.class.getResource("/Dise\u00F1o/fondo_inicio.jpg")));
		fondo.setBounds(-69, -69, 603, 430);
		
		ImageIcon ico = new ImageIcon(getClass().getResource("/Diseño/fondo_inicio.jpg"));
		ImageIcon img = new ImageIcon(ico.getImage().getScaledInstance(fondo.getWidth(), fondo.getWidth(), Image.SCALE_SMOOTH));

		contentPane.add(fondo);
	}
}