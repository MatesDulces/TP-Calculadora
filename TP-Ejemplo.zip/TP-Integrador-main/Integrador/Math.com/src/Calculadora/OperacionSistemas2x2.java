package Calculadora;

import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class OperacionSistemas2x2 extends JPanel {
	private JTextField ec1_x;
	private JTextField ec1_y;
	private JTextField ec1_ti;
	private JTextField ec2_x;
	private JTextField ec2_y;
	private JTextField ec2_ti;

	public OperacionSistemas2x2() {
		setBackground(new Color(60, 60, 60));
		setLayout(null);
		
		ec1_x = new JTextField();
		ec1_x.setHorizontalAlignment(SwingConstants.CENTER);
		ec1_x.setFont(new Font("Meiryo", Font.PLAIN, 18));
		ec1_x.setColumns(10);
		ec1_x.setBounds(150, 74, 39, 31);
		add(ec1_x);
		
		ec1_y = new JTextField();
		ec1_y.setHorizontalAlignment(SwingConstants.CENTER);
		ec1_y.setFont(new Font("Meiryo", Font.PLAIN, 18));
		ec1_y.setColumns(10);
		ec1_y.setBounds(219, 74, 39, 31);
		add(ec1_y);
		
		ec1_ti = new JTextField();
		ec1_ti.setHorizontalAlignment(SwingConstants.CENTER);
		ec1_ti.setFont(new Font("Meiryo", Font.PLAIN, 18));
		ec1_ti.setColumns(10);
		ec1_ti.setBounds(358, 74, 39, 31);
		add(ec1_ti);
		
		JLabel ig1 = new JLabel(" =");
		ig1.setForeground(Color.WHITE);
		ig1.setFont(new Font("Meiryo", Font.BOLD, 25));
		ig1.setBounds(292, 82, 46, 14);
		add(ig1);
		
		ec2_x = new JTextField();
		ec2_x.setHorizontalAlignment(SwingConstants.CENTER);
		ec2_x.setFont(new Font("Meiryo", Font.PLAIN, 18));
		ec2_x.setColumns(10);
		ec2_x.setBounds(150, 116, 39, 31);
		add(ec2_x);
		
		ec2_y = new JTextField();
		ec2_y.setHorizontalAlignment(SwingConstants.CENTER);
		ec2_y.setFont(new Font("Meiryo", Font.PLAIN, 18));
		ec2_y.setColumns(10);
		ec2_y.setBounds(219, 116, 39, 31);
		add(ec2_y);
		
		ec2_ti = new JTextField();
		ec2_ti.setHorizontalAlignment(SwingConstants.CENTER);
		ec2_ti.setFont(new Font("Meiryo", Font.PLAIN, 18));
		ec2_ti.setColumns(10);
		ec2_ti.setBounds(358, 116, 39, 31);
		add(ec2_ti);
		
		JLabel ig2 = new JLabel(" =");
		ig2.setForeground(Color.WHITE);
		ig2.setFont(new Font("Meiryo", Font.BOLD, 25));
		ig2.setBounds(292, 121, 46, 14);
		add(ig2);
		
		JLabel var_x = new JLabel(" X");
		var_x.setHorizontalAlignment(SwingConstants.CENTER);
		var_x.setForeground(Color.WHITE);
		var_x.setFont(new Font("Meiryo", Font.BOLD, 25));
		var_x.setBounds(150, 32, 39, 31);
		add(var_x);
		
		JLabel var_y = new JLabel(" Y");
		var_y.setHorizontalAlignment(SwingConstants.CENTER);
		var_y.setForeground(Color.WHITE);
		var_y.setFont(new Font("Meiryo", Font.BOLD, 25));
		var_y.setBounds(219, 32, 39, 31);
		add(var_y);
		
		JLabel var_ti = new JLabel(" TI");
		var_ti.setHorizontalAlignment(SwingConstants.CENTER);
		var_ti.setForeground(Color.WHITE);
		var_ti.setFont(new Font("Meiryo", Font.BOLD, 25));
		var_ti.setBounds(358, 32, 39, 31);
		add(var_ti);
		
		JTextArea resultado = new JTextArea();
		resultado.setFont(new Font("Meiryo", Font.PLAIN, 18));
		resultado.setBounds(58, 228, 427, 161);
		add(resultado);
		
		JButton limpiar = new JButton("Limpiar");
		limpiar.setForeground(Color.WHITE);
		limpiar.setBackground(new Color(0, 139, 139));
		limpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ec1_x.setText("");
				ec1_y.setText("");
				ec1_ti.setText("");
				ec2_x.setText("");
				ec2_y.setText("");
				ec2_ti.setText("");
				resultado.setText("");
			}
		});
		limpiar.setFont(new Font("Meiryo", Font.BOLD, 18));
		limpiar.setBounds(286, 186, 111, 31);
		add(limpiar);
		
		JButton calcular = new JButton("Calcular");
		calcular.setForeground(Color.WHITE);
		calcular.setBackground(new Color(0, 139, 139));
		calcular.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				float x1 = Float.parseFloat(ec1_x.getText());
				float y1 = Float.parseFloat(ec1_y.getText());
				float ti1 = Float.parseFloat(ec1_ti.getText());
				
				float x2 = Float.parseFloat(ec2_x.getText());
				float y2 = Float.parseFloat(ec2_y.getText());
				float ti2 = Float.parseFloat(ec2_ti.getText());
				
				//METODO DE CRAMER
				float detA = ((x1)*(y2))-((y1)*(x2));
				float detAx = ((ti1)*(y2))-((y1)*(ti2));
				float detAy = ((x1)*(ti2))-((ti1)*(x2));
				
				float x = detAx/detA;
				float y = detAy/detA;
				
				String tit = "             SISTEMAS DE ECUACIONES 2x2 \n                       Metodo de cramer";
				String rta = "\n   DetA = "+detA+"\n   DetAx = "+detAx+"          X = "+x+"\n   DetAy = "+detAy+"           Y = "+y;
				resultado.setText(tit+rta);
				resultado.setEditable(false);
				
			}
		});
		calcular.setFont(new Font("Meiryo", Font.BOLD, 18));
		calcular.setBounds(150, 186, 111, 31);
		add(calcular);
	}
}
