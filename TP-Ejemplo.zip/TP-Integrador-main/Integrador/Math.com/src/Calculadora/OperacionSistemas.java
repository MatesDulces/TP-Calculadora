package Calculadora;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuItem;
import java.awt.Color;
import java.awt.Toolkit;

public class OperacionSistemas extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			OperacionSistemas dialog = new OperacionSistemas();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public OperacionSistemas() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(OperacionSistemas.class.getResource("/Dise\u00F1o/logo.jpg")));
		setBackground(new Color(60, 60, 60));
		setBounds(100, 100, 565, 536);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(60, 60, 60));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		
		setTitle("Calculadora de Sistemas");
		setResizable(false);
		setLocationRelativeTo(null);
		
		contentPanel.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(60, 60, 60));
		panel.setBounds(0, 55, 550, 400);
		contentPanel.add(panel);
		panel.setLayout(new BorderLayout());
		
		JButton opcion1 = new JButton("Sistemas 2x2");
		opcion1.setForeground(Color.WHITE);
		opcion1.setBackground(new Color(0, 139, 139));
		opcion1.setBounds(40, 11, 207, 39);
		opcion1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OperacionSistemas2x2 sistemas2x2 = new OperacionSistemas2x2();
				panel.removeAll();
				panel.add(sistemas2x2, BorderLayout.CENTER);
				panel.revalidate();
				panel.repaint();
			}
		});
		opcion1.setFont(new Font("Meiryo", Font.BOLD, 20));
		contentPanel.add(opcion1);
		
		JButton opcion2 = new JButton("Sistemas 3x3");
		opcion2.setForeground(Color.WHITE);
		opcion2.setBackground(new Color(0, 139, 139));
		opcion2.setBounds(302, 11, 207, 39);
		opcion2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OperacionSistemas3x3 sistemas3x3 = new OperacionSistemas3x3();
				panel.removeAll();
				panel.add(sistemas3x3, BorderLayout.CENTER);
				panel.revalidate();
				panel.repaint();
			}
		});
		opcion2.setFont(new Font("Meiryo", Font.BOLD, 20));
		contentPanel.add(opcion2);
		
		JButton volver = new JButton("Volver ");
		volver.setForeground(Color.WHITE);
		volver.setBackground(new Color(0, 139, 139));
		volver.setBounds(202, 459, 123, 27);
		volver.setFont(new Font("Meiryo", Font.BOLD, 11));
		volver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OperacionSistemas.this.setVisible(false);
				Menu.main(new String [] {});
			}
		});
		contentPanel.add(volver);
	}

}