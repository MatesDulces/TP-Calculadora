package Calculadora;

import javax.swing.*;
import java.awt.event.*;
import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class Menu extends JDialog {

	private final JPanel contentPanel = new JPanel();

	public static void main(String[] args) {
		try {
			Menu dialog = new Menu();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Menu() {
		setBackground(new Color(60, 60, 60));
		setIconImage(Toolkit.getDefaultToolkit().getImage(Menu.class.getResource("/Dise\u00F1o/logo.jpg")));
		setBounds(100, 100, 550, 400);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(60, 60, 60));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		setTitle("Menu de operaciones");
		setLocationRelativeTo(null);
		
		JLabel opcion = new JLabel("Escoger una operacion: ");
		opcion.setBackground(new Color(36, 36, 36));
		opcion.setForeground(new Color(255, 255, 255));
		opcion.setFont(new Font("Meiryo", Font.BOLD, 30));
		opcion.setBounds(78, 24, 384, 36);
		contentPanel.add(opcion);
		
		JButton comun = new JButton("Com\u00FAn");
		comun.setForeground(new Color(255, 255, 255));
		comun.setBackground(new Color(0, 139, 139));
		comun.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OperacionComun.main(new String[]{});
				Menu.this.setVisible(false);
			}
		});
		comun.setFont(new Font("Meiryo", Font.BOLD, 25));
		comun.setBounds(61, 84, 201, 107);
		contentPanel.add(comun);
		
		JButton vectores = new JButton("Vectores");
		vectores.setForeground(new Color(255, 255, 255));
		vectores.setBackground(new Color(0, 139, 139));
		vectores.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OperacionVectores vectores = new OperacionVectores();
				vectores.main(new String[]{});
				Menu.this.setVisible(false);
			}
		});
		vectores.setFont(new Font("Meiryo", Font.BOLD, 25));
		vectores.setBounds(272, 84, 201, 107);
		contentPanel.add(vectores);
		
		JButton matrices = new JButton("Matrices");
		matrices.setBackground(new Color(0, 139, 139));
		matrices.setForeground(new Color(255, 255, 255));
		matrices.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OperacionMatrices matrices = new OperacionMatrices();
				matrices.main(new String[]{});
				Menu.this.setVisible(false);
			}
		});
		matrices.setFont(new Font("Meiryo", Font.BOLD, 25));
		matrices.setBounds(61, 202, 201, 107);
		contentPanel.add(matrices);
		
		JButton sistemas = new JButton("Sistemas");
		sistemas.setBackground(new Color(0, 139, 139));
		sistemas.setForeground(new Color(255, 255, 255));
		sistemas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OperacionSistemas sistemas = new OperacionSistemas();
				sistemas.main(new String[]{});
				Menu.this.setVisible(false);
			}
		});
		sistemas.setFont(new Font("Meiryo", Font.BOLD, 25));
		sistemas.setBounds(272, 202, 201, 107);
		contentPanel.add(sistemas);
	}
}