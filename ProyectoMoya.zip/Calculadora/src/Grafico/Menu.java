package Grafico;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import java.awt.SystemColor;

public class Menu extends JFrame {
double num1;
double num2;
String operacion;

private static final long serialVersionUID = 1L;
private JPanel contentPane;
private JTextField textField;
private JButton btnMatrices;
private JButton btnSistemasDeEcuaciones;
private JButton btnRaiz;
private JButton btnRaizCubica;
private JButton btn7;
private JButton btn8;
private JButton btn9;
private JButton btnX;
private JButton btn4;
private JButton btn5;
private JButton btn6;
private JButton btnmenos;
private JButton btn1;
private JButton btn2;
private JButton btn3;
private JButton btnmas;
private JButton btnC;
private JButton btn0;
private JButton btncoma;
private JButton btnigual;
private JButton btndiv;
private JButton btnpot;

/**
* Launch the application.
*/
public static void main(String[] args) {
EventQueue.invokeLater(new Runnable() {
public void run() {
try {
Menu frame = new Menu();
frame.setVisible(true);
} catch (Exception e) {
e.printStackTrace();
}
}
});
}
private static void presentarVector() {
Vectores misVectores = new Vectores();
misVectores.setVisible(true);
}
private static void presentarMatriz() {
Matrices misMatrices = new Matrices();
misMatrices.setVisible(true);
}
private static void presentarEcuacion() {
Ecuaciones misEcuaciones = new Ecuaciones();
misEcuaciones.setVisible(true);
}


/**
* Create the frame.
*/
public Menu() {
setFont(null);
setForeground(Color.WHITE);
setBackground(new Color(0, 0, 0));
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setBounds(100, 100, 750, 700);
contentPane = new JPanel();
contentPane.setBackground(new Color(225, 231, 240));
contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

setContentPane(contentPane);
contentPane.setLayout(null);

textField = new JTextField();
textField.setFont(new Font("Tahoma", Font.PLAIN, 20));
textField.setBounds(114, 23, 546, 161);
contentPane.add(textField);
textField.setColumns(10);

JButton btnVectores = new JButton("Vectores");
btnVectores.setFont(new Font("Tahoma", Font.PLAIN, 20));
btnVectores.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
presentarVector(); //nombre de la funcion
}
});
btnVectores.setBounds(568, 443, 156, 85);
contentPane.add(btnVectores);

btnMatrices = new JButton("Matrices");
btnMatrices.setFont(new Font("Tahoma", Font.PLAIN, 20));
btnMatrices.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
presentarMatriz();
}
});
btnMatrices.setBounds(568, 325, 156, 85);
contentPane.add(btnMatrices);

btnSistemasDeEcuaciones = new JButton("Sist. Ecu.");
btnSistemasDeEcuaciones.setFont(new Font("Tahoma", Font.PLAIN, 20));
btnSistemasDeEcuaciones.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
presentarEcuacion();
}
});
btnSistemasDeEcuaciones.setBounds(568, 217, 156, 85);
contentPane.add(btnSistemasDeEcuaciones);

btnRaiz = new JButton("√");
btnRaiz.setFont(new Font("Tahoma", Font.PLAIN, 20));
btnRaiz.addActionListener(new ActionListener() {
String seleccionar;
public void actionPerformed(ActionEvent e) {
num1 = Double.parseDouble(textField.getText());
num1 = Math.sqrt(num1);
seleccionar = String.format("%.0f",num1);
textField.setText(seleccionar);
}
});
btnRaiz.setBounds(99, 217, 59, 85);
contentPane.add(btnRaiz);

btnRaizCubica = new JButton("√3");
btnRaizCubica.setFont(new Font("Tahoma", Font.PLAIN, 20));
btnRaizCubica.addActionListener(new ActionListener() {
String seleccionar;
public void actionPerformed(ActionEvent e) {
num1 = Double.parseDouble(textField.getText());
num1 = Math.cbrt(num1);
seleccionar = String.format("%.0f",num1);
textField.setText(seleccionar);
}
});
btnRaizCubica.setBounds(20, 217, 59, 85);
contentPane.add(btnRaizCubica);


btn7 = new JButton("7");
btn7.setFont(new Font("Tahoma", Font.PLAIN, 20));
btn7.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
String ingresenumero = textField.getText() + btn7.getText();
textField.setText(ingresenumero);
}
});
btn7.setBounds(202, 217, 85, 85);
contentPane.add(btn7);

btn8 = new JButton("8");
btn8.setFont(new Font("Tahoma", Font.PLAIN, 20));
btn8.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
String ingresenumero = textField.getText() + btn8.getText();
textField.setText(ingresenumero);
}
});
btn8.setBounds(330, 217, 85, 85);
contentPane.add(btn8);

btn9 = new JButton("9");
btn9.setFont(new Font("Tahoma", Font.PLAIN, 20));
btn9.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
String ingresenumero = textField.getText() + btn9.getText();
textField.setText(ingresenumero);
}
});
btn9.setBounds(446, 217, 85, 85);
contentPane.add(btn9);

btnX = new JButton("x");
btnX.setFont(new Font("Tahoma", Font.PLAIN, 20));
btnX.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
num1 = Double.parseDouble(textField.getText());
textField.setText("");;
operacion = "*";
}
});
btnX.setBounds(20, 565, 59, 85);
contentPane.add(btnX);

btn4 = new JButton("4");
btn4.setFont(new Font("Tahoma", Font.PLAIN, 20));
btn4.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
String ingresenumero = textField.getText() + btn4.getText();
textField.setText(ingresenumero);
}
});
btn4.setBounds(202, 325, 85, 85);
contentPane.add(btn4);

btn5 = new JButton("5");
btn5.setFont(new Font("Tahoma", Font.PLAIN, 20));
btn5.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
String ingresenumero = textField.getText() + btn5.getText();
textField.setText(ingresenumero);
}
});
btn5.setBounds(330, 325, 85, 85);
contentPane.add(btn5);

btn6 = new JButton("6");
btn6.setFont(new Font("Tahoma", Font.PLAIN, 20));
btn6.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
String ingresenumero = textField.getText() + btn6.getText();
textField.setText(ingresenumero);
}
});
btn6.setBounds(446, 325, 85, 85);
contentPane.add(btn6);

btnmenos = new JButton("-");
btnmenos.setFont(new Font("Tahoma", Font.PLAIN, 20));
btnmenos.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
num1 = Double.parseDouble(textField.getText());
textField.setText("");;
operacion = "-";
}
});
btnmenos.setBounds(99, 565, 59, 85);
contentPane.add(btnmenos);

btn1 = new JButton("1");
btn1.setFont(new Font("Tahoma", Font.PLAIN, 20));
btn1.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
String ingresenumero = textField.getText() + btn1.getText();
textField.setText(ingresenumero);
}
});
btn1.setBounds(202, 443, 85, 85);
contentPane.add(btn1);

btn2 = new JButton("2");
btn2.setFont(new Font("Tahoma", Font.PLAIN, 20));
btn2.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
String ingresenumero = textField.getText() + btn2.getText();
textField.setText(ingresenumero);
}
});
btn2.setBounds(330, 443, 85, 85);
contentPane.add(btn2);

btn3 = new JButton("3");
btn3.setFont(new Font("Tahoma", Font.PLAIN, 20));
btn3.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
String ingresenumero = textField.getText() + btn3.getText();
textField.setText(ingresenumero);
}
});
btn3.setBounds(446, 443, 85, 85);
contentPane.add(btn3);

btnmas = new JButton("+");
btnmas.setFont(new Font("Tahoma", Font.PLAIN, 20));
btnmas.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
num1 = Double.parseDouble(textField.getText());
textField.setText("");;
operacion = "+";
}
});
btnmas.setBounds(20, 443, 59, 85);
contentPane.add(btnmas);

btnC = new JButton("C");
btnC.setFont(new Font("Tahoma", Font.PLAIN, 20));
btnC.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
textField.setText("");
}
});
btnC.setBounds(202, 565, 84, 85);
contentPane.add(btnC);

btn0 = new JButton("0");
btn0.setFont(new Font("Tahoma", Font.PLAIN, 20));
btn0.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
String ingresenumero = textField.getText() + btn0.getText();
textField.setText(ingresenumero);
}
});
btn0.setBounds(330, 565, 85, 85);
contentPane.add(btn0);

btncoma = new JButton(".");
btncoma.setFont(new Font("Tahoma", Font.PLAIN, 20));
btncoma.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
String ingresenumero = textField.getText() + btncoma.getText();
textField.setText(ingresenumero);
}
});
btncoma.setBounds(446, 565, 84, 85);
contentPane.add(btncoma);

btnigual = new JButton("=");
btnigual.setFont(new Font("Tahoma", Font.PLAIN, 20));
btnigual.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
String seleccionar;
num2 = Double.parseDouble(textField.getText());
if (operacion == "+")
{
num1 = num1 + num2;
seleccionar = String.format("%.0f",num1);
textField.setText(seleccionar);
//num1 = Double.parseDouble(textField.getText());
}
else if (operacion == "-")
{
num1 = num1 - num2;
seleccionar = String.format("%.0f",num1);
textField.setText(seleccionar);
}
else if (operacion == "/")
{
num1 = num1 / num2;
seleccionar = String.format("%.0f",num1);
textField.setText(seleccionar);
}
else if (operacion == "*")
{
num1 = num1 * num2;
seleccionar = String.format("%.0f",num1);
textField.setText(seleccionar);
}
else if (operacion == "n")
{
num1 = Math.pow(num1, num2);
seleccionar = String.format("%.0f",num1);
textField.setText(seleccionar);
}
}
});
btnigual.setBounds(568, 565, 156, 85);
contentPane.add(btnigual);

btndiv = new JButton("/");
btndiv.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
num1 = Double.parseDouble(textField.getText());
textField.setText("");;
operacion = "/";
}
});
btndiv.setFont(new Font("Tahoma", Font.PLAIN, 20));
btndiv.setBounds(99, 443, 59, 85);
contentPane.add(btndiv);

btnpot = new JButton("n^");
btnpot.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
num1 = Double.parseDouble(textField.getText());
textField.setText("");;
operacion = "n";
}
});
btnpot.setFont(new Font("Tahoma", Font.PLAIN, 20));
btnpot.setBounds(20, 325, 136, 85);
contentPane.add(btnpot);


}
}