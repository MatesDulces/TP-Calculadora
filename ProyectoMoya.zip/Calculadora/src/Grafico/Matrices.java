package Grafico;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class Matrices extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField M1_1;
	private JTextField M1_2;
	private JTextField M1_3;
	private JTextField M1_6;
	private JTextField M1_5;
	private JTextField M1_4;
	private JTextField M1_7;
	private JTextField M1_8;
	private JTextField M1_9;
	private JTextField M2_1;
	private JTextField M2_2;
	private JTextField M2_3;
	private JTextField M2_4;
	private JTextField M2_5;
	private JTextField M2_6;
	private JTextField M2_7;
	private JTextField M2_8;
	private JTextField M2_9;
	private JButton btnNewButton_2;
	private JButton btnNewButton_3;
	private JButton btnNewButton_4;
	private JButton btnNewButton_5;
	private JButton btnNewButton_6;
	private JButton btnNewButton_7;
	private JButton btnNewButton_8;
	private JButton Matriz2x2A;
	private JButton Matriz3x3A;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Matrices frame = new Matrices();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Matrices() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 759, 468);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Matrices");
		lblNewLabel.setBounds(326, 11, 74, 25);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		contentPane.add(lblNewLabel);
		
		M1_1 = new JTextField();
		M1_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		M1_1.setHorizontalAlignment(SwingConstants.CENTER);
		M1_1.setBounds(23, 50, 80, 80);
		contentPane.add(M1_1);
		M1_1.setColumns(10);
		
		M1_2 = new JTextField();
		M1_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		M1_2.setHorizontalAlignment(SwingConstants.CENTER);
		M1_2.setColumns(10);
		M1_2.setBounds(113, 50, 80, 80);
		contentPane.add(M1_2);
		
		M1_3 = new JTextField();
		M1_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		M1_3.setHorizontalAlignment(SwingConstants.CENTER);
		M1_3.setColumns(10);
		M1_3.setBounds(203, 50, 80, 80);
		contentPane.add(M1_3);
		
		M1_6 = new JTextField();
		M1_6.setFont(new Font("Tahoma", Font.PLAIN, 20));
		M1_6.setHorizontalAlignment(SwingConstants.CENTER);
		M1_6.setColumns(10);
		M1_6.setBounds(203, 141, 80, 80);
		contentPane.add(M1_6);
		
		M1_5 = new JTextField();
		M1_5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		M1_5.setHorizontalAlignment(SwingConstants.CENTER);
		M1_5.setColumns(10);
		M1_5.setBounds(113, 141, 80, 80);
		contentPane.add(M1_5);
		
		M1_4 = new JTextField();
		M1_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		M1_4.setHorizontalAlignment(SwingConstants.CENTER);
		M1_4.setColumns(10);
		M1_4.setBounds(23, 141, 80, 80);
		contentPane.add(M1_4);
		
		M1_7 = new JTextField();
		M1_7.setFont(new Font("Tahoma", Font.PLAIN, 20));
		M1_7.setHorizontalAlignment(SwingConstants.CENTER);
		M1_7.setColumns(10);
		M1_7.setBounds(23, 232, 80, 80);
		contentPane.add(M1_7);
		
		M1_8 = new JTextField();
		M1_8.setFont(new Font("Tahoma", Font.PLAIN, 20));
		M1_8.setHorizontalAlignment(SwingConstants.CENTER);
		M1_8.setColumns(10);
		M1_8.setBounds(113, 232, 80, 80);
		contentPane.add(M1_8);
		
		M1_9 = new JTextField();
		M1_9.setFont(new Font("Tahoma", Font.PLAIN, 20));
		M1_9.setHorizontalAlignment(SwingConstants.CENTER);
		M1_9.setColumns(10);
		M1_9.setBounds(203, 232, 80, 80);
		contentPane.add(M1_9);
		
		M2_1 = new JTextField();
		M2_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		M2_1.setHorizontalAlignment(SwingConstants.CENTER);
		M2_1.setColumns(10);
		M2_1.setBounds(448, 50, 80, 80);
		contentPane.add(M2_1);
		
		M2_2 = new JTextField();
		M2_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		M2_2.setHorizontalAlignment(SwingConstants.CENTER);
		M2_2.setColumns(10);
		M2_2.setBounds(538, 50, 80, 80);
		contentPane.add(M2_2);
		
		M2_3 = new JTextField();
		M2_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		M2_3.setHorizontalAlignment(SwingConstants.CENTER);
		M2_3.setColumns(10);
		M2_3.setBounds(628, 50, 80, 80);
		contentPane.add(M2_3);
		
		M2_4 = new JTextField();
		M2_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		M2_4.setHorizontalAlignment(SwingConstants.CENTER);
		M2_4.setColumns(10);
		M2_4.setBounds(448, 141, 80, 80);
		contentPane.add(M2_4);
		
		M2_5 = new JTextField();
		M2_5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		M2_5.setHorizontalAlignment(SwingConstants.CENTER);
		M2_5.setColumns(10);
		M2_5.setBounds(538, 141, 80, 80);
		contentPane.add(M2_5);
		
		M2_6 = new JTextField();
		M2_6.setFont(new Font("Tahoma", Font.PLAIN, 20));
		M2_6.setHorizontalAlignment(SwingConstants.CENTER);
		M2_6.setColumns(10);
		M2_6.setBounds(628, 141, 80, 80);
		contentPane.add(M2_6);
		
		M2_7 = new JTextField();
		M2_7.setFont(new Font("Tahoma", Font.PLAIN, 20));
		M2_7.setHorizontalAlignment(SwingConstants.CENTER);
		M2_7.setColumns(10);
		M2_7.setBounds(448, 232, 80, 80);
		contentPane.add(M2_7);
		
		M2_8 = new JTextField();
		M2_8.setFont(new Font("Tahoma", Font.PLAIN, 20));
		M2_8.setHorizontalAlignment(SwingConstants.CENTER);
		M2_8.setColumns(10);
		M2_8.setBounds(538, 232, 80, 80);
		contentPane.add(M2_8);
		
		M2_9 = new JTextField();
		M2_9.setFont(new Font("Tahoma", Font.PLAIN, 20));
		M2_9.setHorizontalAlignment(SwingConstants.CENTER);
		M2_9.setColumns(10);
		M2_9.setBounds(628, 232, 80, 80);
		contentPane.add(M2_9);
		
		JButton btnNewButton = new JButton("+");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(293, 79, 145, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("-");
		btnNewButton_1.setBounds(293, 124, 145, 23);
		contentPane.add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("x");
		btnNewButton_2.setBounds(293, 170, 145, 23);
		contentPane.add(btnNewButton_2);
		
		btnNewButton_3 = new JButton("/");
		btnNewButton_3.setBounds(293, 215, 145, 23);
		contentPane.add(btnNewButton_3);
		
		btnNewButton_4 = new JButton("Determinante");
		btnNewButton_4.setBounds(23, 323, 128, 23);
		contentPane.add(btnNewButton_4);
		
		btnNewButton_5 = new JButton("Inversa");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_5.setBounds(155, 323, 128, 23);
		contentPane.add(btnNewButton_5);
		
		btnNewButton_6 = new JButton("X escalares");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_6.setBounds(293, 261, 145, 23);
		contentPane.add(btnNewButton_6);
		
		btnNewButton_7 = new JButton("Determinante");
		btnNewButton_7.setBounds(448, 323, 128, 23);
		contentPane.add(btnNewButton_7);
		
		btnNewButton_8 = new JButton("Inversa");
		btnNewButton_8.setBounds(580, 323, 128, 23);
		contentPane.add(btnNewButton_8);
		
		Matriz2x2A = new JButton("Matriz 2x2");
		Matriz2x2A.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				M1_3.setVisible(false);
				M1_6.setVisible(false);
				M1_7.setVisible(false);
				M1_8.setVisible(false);
				M1_9.setVisible(false);
				M2_3.setVisible(false);
				M2_6.setVisible(false);
				M2_7.setVisible(false);
				M2_8.setVisible(false);
				M2_9.setVisible(false);
			}
		});
		Matriz2x2A.setBounds(236, 357, 260, 23);
		contentPane.add(Matriz2x2A);
		
		Matriz3x3A = new JButton("Matriz 3x3");
		Matriz3x3A.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				M1_3.setVisible(true);
				M1_6.setVisible(true);
				M1_7.setVisible(true);
				M1_8.setVisible(true);
				M1_9.setVisible(true);
				M2_3.setVisible(true);
				M2_6.setVisible(true);
				M2_7.setVisible(true);
				M2_8.setVisible(true);
				M2_9.setVisible(true);
			}
		});
		Matriz3x3A.setBounds(236, 391, 260, 23);
		contentPane.add(Matriz3x3A);
		
		JButton btnNewButton_9 = new JButton("Menu");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_9.setBounds(23, 16, 89, 23);
		contentPane.add(btnNewButton_9);
	}
}
