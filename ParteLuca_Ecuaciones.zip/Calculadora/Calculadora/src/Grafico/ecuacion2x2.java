package Grafico;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.JLayeredPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JTextPane;

public class ecuacion2x2 extends JFrame {

	Menu ventana_Menu = new Menu();

    private JPanel contentPane;
    private JTextField textFieldx1;
    private JTextField textFieldx2;
    private JTextField textFieldy1;
    private JTextField textFieldy2;
    private JTextField textFieldr1;
    private JTextField textFieldr2;
    private JTextField focusedTextField; 
    private JTextField result1;
    private JTextField result2;
    private boolean isDecimalMode = false; // Variable para controlar el modo de número (entero o decimal)
    
    
  
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ecuacion2x2 frame = new ecuacion2x2();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void insertarNumero(JButton boton) {
        boton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (focusedTextField != null) {
                    String numero = focusedTextField.getText() + boton.getText();
                    focusedTextField.setText(numero);
                }
            }
        });
    }
    
    private double determinant(double[][] matrix) {
        return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
    }

    private double[] resolverSistemaEcuaciones(double[][] coeficientes, double[] resultados) throws Exception {
        double detD = determinant(coeficientes);
        
        if (detD == 0) {
            throw new Exception("El sistema no tiene solución única.");
        }
        
        double[][] matrizDx = {
            { resultados[0], coeficientes[0][1] },
            { resultados[1], coeficientes[1][1] }
        };
        
        double[][] matrizDy = {
            { coeficientes[0][0], resultados[0] },
            { coeficientes[1][0], resultados[1] }
        };

        double detDx = determinant(matrizDx);
        double detDy = determinant(matrizDy);

        double[] solution = new double[2];
        solution[0] = detDx / detD;
        solution[1] = detDy / detD;

        return solution;
    }

	/**
	 * Create the frame.
	 */
	public ecuacion2x2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	setBounds(100, 100, 541, 647);
    	contentPane = new JPanel();
    	contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

    	setContentPane(contentPane);
    	contentPane.setLayout(null);
    	
    	textFieldy2 = new JTextField();
    	textFieldy2.setEditable(false);
    	textFieldy2.setColumns(10);
    	textFieldy2.setBounds(280, 126, 61, 37);
    	contentPane.add(textFieldy2);
    	
    	textFieldy1 = new JTextField();
    	textFieldy1.setEditable(false);
    	textFieldy1.setColumns(10);
    	textFieldy1.setBounds(280, 56, 61, 37);
    	contentPane.add(textFieldy1);
    	
    	textFieldx2 = new JTextField();
    	textFieldx2.setEditable(false);
    	textFieldx2.setColumns(10);
    	textFieldx2.setBounds(130, 126, 61, 37);
    	contentPane.add(textFieldx2);
    	
    	textFieldx1 = new JTextField();
    	textFieldx1.setEditable(false);
    	textFieldx1.setBounds(130, 56, 61, 37);
    	contentPane.add(textFieldx1);
    	textFieldx1.setColumns(10);
    	
    	JLabel lblNewLabel = new JLabel("Ecuaciones 2x2");
    	lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
    	lblNewLabel.setBounds(199, 11, 136, 25);
    	lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	contentPane.add(lblNewLabel);
    	
    	JTextPane txtpnEcuacion = new JTextPane();
    	txtpnEcuacion.setEditable(false);
    	txtpnEcuacion.setBackground(UIManager.getColor("Button.background"));
    	txtpnEcuacion.setText("Ecuacion 1");
    	txtpnEcuacion.setBounds(10, 65, 71, 20);
    	contentPane.add(txtpnEcuacion);
    	
    	JTextPane txtpnEcuacion_2 = new JTextPane();
    	txtpnEcuacion_2.setEditable(false);
    	txtpnEcuacion_2.setText("Ecuacion 2");
    	txtpnEcuacion_2.setBackground(SystemColor.menu);
    	txtpnEcuacion_2.setBounds(10, 135, 71, 20);
    	contentPane.add(txtpnEcuacion_2);
    	
    	JTextPane txtpnX = new JTextPane();
    	txtpnX.setEditable(false);
    	txtpnX.setText("x1=");
    	txtpnX.setBackground(SystemColor.menu);
    	txtpnX.setBounds(90, 65, 61, 20);
    	contentPane.add(txtpnX);
    	
    	JTextPane txtpnX_1 = new JTextPane();
    	txtpnX_1.setEditable(false);
    	txtpnX_1.setText("x2=");
    	txtpnX_1.setBackground(SystemColor.menu);
    	txtpnX_1.setBounds(90, 135, 61, 20);
    	contentPane.add(txtpnX_1);
    	
    	JTextPane txtpnY = new JTextPane();
    	txtpnY.setEditable(false);
    	txtpnY.setText("y1=");
    	txtpnY.setBackground(SystemColor.menu);
    	txtpnY.setBounds(240, 65, 61, 20);
    	contentPane.add(txtpnY);
    	
    	JTextPane txtpnY_1 = new JTextPane();
    	txtpnY_1.setEditable(false);
    	txtpnY_1.setText("y2=");
    	txtpnY_1.setBackground(SystemColor.menu);
    	txtpnY_1.setBounds(240, 135, 61, 20);
    	contentPane.add(txtpnY_1);
    	
    	textFieldr1 = new JTextField();
    	textFieldr1.setEditable(false);
    	textFieldr1.setColumns(10);
    	textFieldr1.setBounds(422, 56, 61, 37);
    	contentPane.add(textFieldr1);
    	
    	textFieldr2 = new JTextField();
    	textFieldr2.setEditable(false);
    	textFieldr2.setColumns(10);
    	textFieldr2.setBounds(422, 126, 61, 37);
    	contentPane.add(textFieldr2);
    	
    	JTextPane txtpnY_2 = new JTextPane();
    	txtpnY_2.setEditable(false);
    	txtpnY_2.setText("=");
    	txtpnY_2.setBackground(SystemColor.menu);
    	txtpnY_2.setBounds(370, 65, 61, 20);
    	contentPane.add(txtpnY_2);
    	
    	JTextPane txtpnY_2_1 = new JTextPane();
    	txtpnY_2_1.setEditable(false);
    	txtpnY_2_1.setText("=");
    	txtpnY_2_1.setBackground(SystemColor.menu);
    	txtpnY_2_1.setBounds(370, 135, 61, 20);
    	contentPane.add(txtpnY_2_1);
    	
    	JTextPane txtpnX_2 = new JTextPane();
    	txtpnX_2.setEditable(false);
    	txtpnX_2.setText("+");
    	txtpnX_2.setBackground(SystemColor.menu);
    	txtpnX_2.setBounds(182, 65, 15, 20);
    	contentPane.add(txtpnX_2);
    	
    	JTextPane txtpnX_2_1 = new JTextPane();
    	txtpnX_2_1.setEditable(false);
    	txtpnX_2_1.setText("+");
    	txtpnX_2_1.setBackground(SystemColor.menu);
    	txtpnX_2_1.setBounds(182, 135, 15, 20);
    	contentPane.add(txtpnX_2_1);

        JButton btn7 = new JButton("7");
    	btn7.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn7.setBounds(20, 200, 85, 85);
    	contentPane.add(btn7);
    	insertarNumero(btn7);
    	
    	JButton btn8 = new JButton("8");
    	btn8.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn8.setBounds(150, 200, 85, 85);
    	contentPane.add(btn8);
    	insertarNumero(btn8);
    	
    	JButton btn9 = new JButton("9");
    	btn9.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn9.setBounds(280, 200, 85, 85);
    	contentPane.add(btn9);
    	insertarNumero(btn9);
    	
    	JButton btn4 = new JButton("4");
    	btn4.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn4.setBounds(20, 296, 85, 85);
    	contentPane.add(btn4);
    	insertarNumero(btn4);
    	
    	JButton btn1 = new JButton("1");
    	btn1.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn1.setBounds(20, 392, 85, 85);
    	contentPane.add(btn1);
    	insertarNumero(btn1);
    	
    	JButton btnigual = new JButton("=");
    	btnigual.addActionListener(new ActionListener() {
    	    public void actionPerformed(ActionEvent e) {
    	        try {
    	            double[][] coeficientes = {
    	                    { Double.parseDouble(textFieldx1.getText()), Double.parseDouble(textFieldy1.getText()) },
    	                    { Double.parseDouble(textFieldx2.getText()), Double.parseDouble(textFieldy2.getText()) }
    	            };
    	                   
    	            double[] resultados = {
    	                    Double.parseDouble(textFieldr1.getText()),
    	                    Double.parseDouble(textFieldr2.getText())
    	                    
    	            };

    	            double[] solucion = resolverSistemaEcuaciones(coeficientes, resultados);

    	            // Actualizar los campos de texto de los resultados
    	            result1.setText(String.format("%.2f", solucion[0]));
    	            result2.setText(String.format("%.2f", solucion[1]));
    	          

    	        } catch (Exception ex) {
    	            // Manejar la excepción (por ejemplo, mostrar un mensaje de error)
    	            ex.printStackTrace();
    	        }
    	    }
    	});
    	btnigual.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btnigual.setBounds(20, 488, 85, 85);
    	contentPane.add(btnigual);
    	
    	JButton btn5 = new JButton("5");
    	btn5.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn5.setBounds(150, 296, 85, 85);
    	contentPane.add(btn5);
    	insertarNumero(btn5);
    	
    	JButton btn6 = new JButton("6");
    	btn6.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn6.setBounds(280, 296, 85, 85);
    	contentPane.add(btn6);
    	insertarNumero(btn6);
    	
    	JButton btn2 = new JButton("2");
    	btn2.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn2.setBounds(150, 392, 85, 85);
    	contentPane.add(btn2);
    	insertarNumero(btn2);
    	
    	JButton btn3 = new JButton("3");
    	btn3.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn3.setBounds(280, 392, 85, 85);
    	contentPane.add(btn3);
    	insertarNumero(btn3);
    	
    	JButton btn0 = new JButton("0");
    	btn0.setFont(new Font("Tahoma", Font.PLAIN, 20));
    	btn0.setBounds(150, 488, 85, 85);
    	contentPane.add(btn0);
    	insertarNumero(btn0);

        JButton btnBorrar = new JButton("DEL");
        btnBorrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (focusedTextField != null) {
                    String currentText = focusedTextField.getText();
                    if (currentText.length() > 0) {
                        focusedTextField.setText(currentText.substring(0, currentText.length() - 1));
                    }
                }
            }
        });
        btnBorrar.setBounds(280, 488, 85, 85);
        contentPane.add(btnBorrar);
        
        result1 = new JTextField();
        result1.setEditable(false);
        result1.setColumns(10);
        result1.setBounds(422, 192, 61, 37);
        contentPane.add(result1);
        
        result2 = new JTextField();
        result2.setEditable(false);
        result2.setColumns(10);
        result2.setBounds(422, 240, 61, 37);
        contentPane.add(result2);
        
        JTextPane Xrest = new JTextPane();
        Xrest.setText("X=");
        Xrest.setEditable(false);
        Xrest.setBackground(SystemColor.menu);
        Xrest.setBounds(397, 200, 61, 20);
        contentPane.add(Xrest);
        
        JTextPane Yrest = new JTextPane();
        Yrest.setText("Y=");
        Yrest.setEditable(false);
        Yrest.setBackground(SystemColor.menu);
        Yrest.setBounds(397, 250, 61, 20);
        contentPane.add(Yrest);
        
        JButton btnNewButton = new JButton("Volver");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
    				ventana_Menu.setVisible(true);	
    				dispose();
        	}
        });
        btnNewButton.setBounds(10, 11, 89, 25);
        contentPane.add(btnNewButton);
        
        JButton btnC = new JButton("C");
        btnC.addActionListener(new ActionListener() {
        	 public void actionPerformed(ActionEvent e) {
        	        textFieldx1.setText("");
        	        textFieldx2.setText("");
        	       
        	        textFieldy1.setText("");
        	        textFieldy2.setText("");
        	       
        	        textFieldr1.setText("");
        	        textFieldr2.setText("");
        	        
        	        result1.setText("");
        	        result2.setText("");
        	       
        	    }
        	});
        btnC.setBounds(397, 488, 85, 85);
        contentPane.add(btnC);
        
        JButton btnCambiarSigno = new JButton("+/-");
        btnCambiarSigno.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (focusedTextField != null) {
                    String currentText = focusedTextField.getText();
                    if (!currentText.isEmpty()) {
                        double number = Double.parseDouble(currentText);
                        number = -number; // Cambiar signo
                        focusedTextField.setText(Double.toString(number));
                    }
                }
            }
        });
        btnCambiarSigno.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnCambiarSigno.setBounds(397, 437, 86, 40);
        contentPane.add(btnCambiarSigno);
        
        JTextPane txtpnX_3 = new JTextPane();
        txtpnX_3.setText("+");
        txtpnX_3.setEditable(false);
        txtpnX_3.setBackground(SystemColor.menu);
        txtpnX_3.setBounds(211, 65, 15, 20);
        contentPane.add(txtpnX_3);
        
        JTextPane txtpnX_3_1 = new JTextPane();
        txtpnX_3_1.setText("+");
        txtpnX_3_1.setEditable(false);
        txtpnX_3_1.setBackground(SystemColor.menu);
        txtpnX_3_1.setBounds(211, 135, 15, 20);
        contentPane.add(txtpnX_3_1);
        
        JButton btnPunto = new JButton(".");
        	btnPunto.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if (focusedTextField != null) {
                        String currentText = focusedTextField.getText();
                        if (!currentText.isEmpty()) {
                            if (isDecimalMode) {
                                // Convertir a entero
                                try {
                                    int number = (int) Double.parseDouble(currentText);
                                    focusedTextField.setText(Integer.toString(number));
                                } catch (NumberFormatException ex) {
                                    // Handle parse error (shouldn't happen if input is controlled)
                                    focusedTextField.setText("0");
                                }
                            } else {
                                // Convertir a decimal
                                try {
                                    double number = Double.parseDouble(currentText);
                                    focusedTextField.setText(Double.toString(number));
                                } catch (NumberFormatException ex) {
                                    // Handle parse error (shouldn't happen if input is controlled)
                                    focusedTextField.setText("0.0");
                                }
                            }
                            isDecimalMode = !isDecimalMode; // Alternar modo
                        }
                    }
                }
            });
        btnPunto.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnPunto.setBounds(397, 392, 86, 40);
        contentPane.add(btnPunto);

        // Agregar FocusListener a cada campo de texto
        FocusAdapter focusAdapter = new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                focusedTextField = (JTextField) e.getSource();
            }
        };

        textFieldx1.addFocusListener(focusAdapter);
        textFieldx2.addFocusListener(focusAdapter);
        textFieldy1.addFocusListener(focusAdapter);
        textFieldy2.addFocusListener(focusAdapter);
        textFieldr1.addFocusListener(focusAdapter);
        textFieldr2.addFocusListener(focusAdapter);
    }
}
